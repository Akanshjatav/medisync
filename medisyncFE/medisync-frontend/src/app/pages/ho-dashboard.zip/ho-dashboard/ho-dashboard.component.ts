import { Component, HostListener, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { DashboardService } from '../../core/services/ho-dashboard.service';
import { DashboardSummary } from '../../core/models/dashboard.models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class HoDashboardComponent implements OnInit {
  // ==========================
  // DI
  // ==========================
  private dashboardService = inject(DashboardService);
  private router = inject(Router);

  // ==========================
  // UI State
  // ==========================
  sidebarOpen = signal(false);
  accountMenuOpen = signal(false);

  // ==========================
  // Data State
  // ==========================
  loading = signal(true);
  error = signal<string | null>(null);
  summary = signal<DashboardSummary | null>(null);

  // ✅ Keep your template usage: {{ todayLabel() }}
  todayLabel = computed(() => {
    const d = new Date();
    return d.toLocaleDateString(undefined, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: '2-digit'
    });
  });

  // ==========================
  // Lifecycle
  // ==========================
  ngOnInit(): void {
    this.loadDashboard();
  }

  // ==========================
  // Load dashboard (Frontend computed summary)
  // ==========================
  loadDashboard(): void {
    this.loading.set(true);
    this.error.set(null);

    this.dashboardService.getSummary().subscribe({
      next: (summary) => {
        this.summary.set(summary);
        this.loading.set(false);
      },
      error: (err) => {
        console.error(err);
        this.error.set('Failed to load dashboard data.');
        this.loading.set(false);
      }
    });
  }

  logout(): void {
    const ok = confirm('Are you sure you want to logout?');
    if (!ok) return;

    this.dashboardService.logout().subscribe({
      next: () => this.finishLogout(),
      error: () => this.finishLogout()
    });
  }

  private finishLogout(): void {
    localStorage.removeItem('token');
    this.router.navigateByUrl('/login');
  }

  // ==========================
  // UI events
  // ==========================
  toggleSidebar(): void {
    this.sidebarOpen.update(v => !v);
  }

  closeSidebar(): void {
    this.sidebarOpen.set(false);
  }

  toggleAccountMenu(): void {
    this.accountMenuOpen.update(v => !v);
  }

  closeAccountMenu(): void {
    this.accountMenuOpen.set(false);
  }

  @HostListener('document:keydown.escape')
  onEsc(): void {
    this.accountMenuOpen.set(false);
    this.sidebarOpen.set(false);
  }

  @HostListener('document:click', ['$event'])
  onDocClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (!target.closest('#accountMenu')) {
      this.accountMenuOpen.set(false);
    }
  }
}