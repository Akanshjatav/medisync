
package com.tcs.ilp.pharmacy.medisync.repository;

import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface RfqRepository extends JpaRepository<Rfq, Integer> {

    List<Rfq> findByStore_StoreId(Integer storeId);

    List<Rfq> findByStatus(String status);
    List<Rfq> findByCreatedBy_UserId(Integer userId);

    List<Rfq> findByCreatedAtBetween(LocalDateTime from, LocalDateTime to);
}
