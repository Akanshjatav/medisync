package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.BidDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidItemsUpdateDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidRequestDto;
import com.tcs.ilp.pharmacy.medisync.entity.BidItems;
import com.tcs.ilp.pharmacy.medisync.entity.Bids;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.Vendor;
import com.tcs.ilp.pharmacy.medisync.exception.ResourceNotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.BidsRepository;
import com.tcs.ilp.pharmacy.medisync.repository.RfqRepository;
import com.tcs.ilp.pharmacy.medisync.repository.VendorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class BidsService {

    private final BidsRepository bidsRepo;
    private final VendorRepository vendorRepo;
    private final RfqRepository rfqRepo;

    public BidsService(BidsRepository bidsRepo,
                       VendorRepository vendorRepo,
                       RfqRepository rfqRepo) {
        this.bidsRepo = bidsRepo;
        this.vendorRepo = vendorRepo;
        this.rfqRepo = rfqRepo;
    }

    // =====================================================
    // CREATE
    // =====================================================

    public Bids createBid(BidRequestDto request) {

        Vendor vendor = vendorRepo.findById(request.getVendorId())
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found"));

        Rfq rfq = rfqRepo.findById(request.getRfqId())
                .orElseThrow(() -> new ResourceNotFoundException("RFQ not found"));

        Bids bid = new Bids();
        bid.setVendor(vendor);
        bid.setRfq(rfq);

        if (request.getItems() != null && !request.getItems().isEmpty()) {
            bid.setItems(toBidItems(request.getItems(), bid));
        }

        return bidsRepo.save(bid);
    }

    // =====================================================
    // READ (DTO-facing)
    // =====================================================

    @Transactional(readOnly = true)
    public List<BidDto> getBidsForRfq(Integer rfqId) {
        return bidsRepo.findByRfq_RfqId(rfqId)
                .stream()
                .map(this::toDto)
                .toList();
    }

    // =====================================================
    // READ (internal / entity-level)
    // =====================================================

    @Transactional(readOnly = true)
    public Bids getBid(Integer bidId) {
        return bidsRepo.findById(bidId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Bid not found: " + bidId));
    }

    @Transactional(readOnly = true)
    public List<BidDto> getAllBids() {
        return bidsRepo.findAll()
                .stream()
                .map(this::toDto)
                .toList();
    }

    public void updateBidItems(Integer bidId, BidItemsUpdateDto request) {

        Bids bid = getBid(bidId);

        // clear existing items (orphanRemoval = true)
        bid.getItems().clear();

        if (request.getItems() != null && !request.getItems().isEmpty()) {
            bid.getItems().addAll(toBidItems(request.getItems(), bid));
        }

        bidsRepo.save(bid);
    }




    // =====================================================
    // DELETE
    // =====================================================

    public void delete(Integer bidId) {
        bidsRepo.delete(getBid(bidId));
    }

    // =====================================================
    // MAPPING (private helpers)
    // =====================================================

    private List<BidItems> toBidItems(List<BidItemDto> dtos, Bids bid) {

        List<BidItems> items = new ArrayList<>();

        for (BidItemDto dto : dtos) {
            BidItems item = new BidItems();
            item.setMedicineName(dto.getMedicineName());
            item.setItemQuantity(dto.getItemQuantity());
            item.setItemPrice(dto.getItemPrice());
            item.setBids(bid);
            items.add(item);
        }

        return items;
    }

    private BidDto toDto(Bids bid) {

        BidDto dto = new BidDto();
        dto.setBidId(bid.getBidId());
        dto.setRfqId(bid.getRfq().getRfqId());
        dto.setVendorId(bid.getVendor().getVendorId());
        dto.setVendorName(bid.getVendor().getUser().getName());
        dto.setStatus(bid.getStatus());

        List<BidItemDto> items = bid.getItems().stream().map(i -> {
            BidItemDto it = new BidItemDto();
            it.setMedicineName(i.getMedicineName());
            it.setItemQuantity(i.getItemQuantity());
            it.setItemPrice(i.getItemPrice());
            return it;
        }).toList();

        dto.setItems(items);
        return dto;
    }
}
