package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.*;
import com.tcs.ilp.pharmacy.medisync.entity.Batch;
import com.tcs.ilp.pharmacy.medisync.entity.Product;
import com.tcs.ilp.pharmacy.medisync.service.BatchService;
import com.tcs.ilp.pharmacy.medisync.service.InventoryService;
import com.tcs.ilp.pharmacy.medisync.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ph")
public class PharmacistController {

    private final InventoryService inventoryService;
    private final BatchService batchService;
    private final ProductService productService;

    public PharmacistController(
            InventoryService inventoryService,
            BatchService batchService,
            ProductService productService
    ) {
        this.inventoryService = inventoryService;
        this.batchService = batchService;
        this.productService = productService;
    }

    // =====================================================
    // 1️⃣ VIEW INVENTORY
    // =====================================================
    @GetMapping("/inventory/{storeId}")
    public ResponseEntity<BranchInventoryResponse> viewInventory(
            @PathVariable Integer storeId
    ) {
        return ResponseEntity.ok(
                inventoryService.getBranchInventoryDetails(storeId)
        );
    }

    // =====================================================
    // 2️⃣ CREATE BATCH WITH PRODUCTS
    // =====================================================
    @PostMapping("/batches")
    public ResponseEntity<BatchResponse> createBatch(
            @RequestBody BatchCreateRequest request
    ) {
        Batch batch = batchService.createBatchWithProducts(request);

        BatchResponse response = new BatchResponse();
        response.setBatchId(batch.getBatchId());

        for (Product p : batch.getProducts()) {
            response.getProducts().add(
                    new ProductResponse(
                            p.getProductId(),
                            p.getProductName(),
                            p.getCategory(),
                            p.getQuantityTotal(),
                            p.getPrice(),
                            p.getExpiryDate(),
                            batch.getBatchId()
                    )
            );
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // =====================================================
    // 3️⃣ DISPENSE PRODUCT
    // =====================================================
    @PostMapping("/products/{productId}/dispense")
    public ResponseEntity<String> dispense(
            @PathVariable Integer productId,
            @RequestParam Integer quantity
    ) {
        productService.dispenseProduct(productId, quantity);
        return ResponseEntity.ok("Dispensed successfully");
    }
}
