package com.tcs.ilp.pharmacy.medisync.exception;

public class BidItemValidationexception extends RuntimeException {
    public BidItemValidationexception(String message) {
        super(message);
    }
}
