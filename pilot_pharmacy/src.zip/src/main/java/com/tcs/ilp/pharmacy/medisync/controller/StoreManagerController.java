package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.BidDto;
import com.tcs.ilp.pharmacy.medisync.dto.RfqPayloadDto;
import com.tcs.ilp.pharmacy.medisync.dto.StockRequestDto;
import com.tcs.ilp.pharmacy.medisync.service.BidsService;
import com.tcs.ilp.pharmacy.medisync.service.RfqService;
import com.tcs.ilp.pharmacy.medisync.service.StockRequestService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sm")
public class StoreManagerController {

    private final RfqService rfqService;
    private final StockRequestService stockRequestService;
    private final BidsService bidsService;

    public StoreManagerController(RfqService rfqService,
                                  StockRequestService stockRequestService,
                                  BidsService bidsService) {
        this.rfqService = rfqService;
        this.stockRequestService = stockRequestService;
        this.bidsService = bidsService;
    }

    // =====================================================
    // RFQ MANAGEMENT
    // =====================================================

    @PostMapping("/rfqs")
    public ResponseEntity<RfqPayloadDto> createRfq(
            @RequestBody RfqPayloadDto payload) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(rfqService.createRfq(payload));
    }

    @GetMapping("/rfqs")
    public List<RfqPayloadDto> getAllRfqs() {
        return rfqService.listAll(); // must return DTOs (as per your new design)
    }

    @GetMapping("/rfqs/{rfqId}")
    public RfqPayloadDto getRfq(@PathVariable Integer rfqId) {
        return rfqService.getRfq(rfqId);
    }

    @PutMapping("/rfqs/{rfqId}")
    public RfqPayloadDto updateRfq(@PathVariable Integer rfqId,
                                   @RequestBody RfqPayloadDto payload) {
        return rfqService.updateRfq(rfqId, payload);
    }

    @DeleteMapping("/rfqs/{rfqId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteRfq(@PathVariable Integer rfqId) {
        rfqService.delete(rfqId);
    }

    @PostMapping("/rfqs/{rfqId}/award")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void awardRfq(@PathVariable Integer rfqId,
                         @RequestParam String status) {
        rfqService.award(rfqId, status);
    }

    // =====================================================
    // RFQ → BIDS
    // =====================================================

    @GetMapping("/rfqs/{rfqId}/bids")
    public List<BidDto> viewBidsForRfq(@PathVariable Integer rfqId) {
        return bidsService.getBidsForRfq(rfqId);
    }

    // (optional, only if you expose it)
    @GetMapping("/bids")
    public List<BidDto> getAllBids() {
        return bidsService.getAllBids();
    }

    // =====================================================
    // STOCK REQUEST RESPONSES
    // =====================================================

    @GetMapping("/stock-requests")
    public List<StockRequestDto> getStockRequestsByStatus(
            @RequestParam String status) {
        return stockRequestService.findByStatus(status);
    }

    @PostMapping("/stock-requests/{requestId}/approve")
    public StockRequestDto approveStockRequest(
            @PathVariable Integer requestId,
            @RequestParam Integer approverUserId) {
        return stockRequestService.approve(requestId, approverUserId);
    }

    @PostMapping("/stock-requests/{requestId}/reject")
    public StockRequestDto rejectStockRequest(
            @PathVariable Integer requestId,
            @RequestParam Integer approverUserId,
            @RequestParam(required = false) String remarks) {
        return stockRequestService.reject(requestId, approverUserId, remarks);
    }

    @PostMapping("/stock-requests/{requestId}/fulfill")
    public StockRequestDto fulfillStockRequest(
            @PathVariable Integer requestId) {
        return stockRequestService.fulfill(requestId);
    }
}
