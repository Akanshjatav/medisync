package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.RfqDto;
import com.tcs.ilp.pharmacy.medisync.dto.RfqItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.RfqPayloadDto;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.RfqItems;
import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.RfqRepository;
import com.tcs.ilp.pharmacy.medisync.repository.StoreRepository;
import com.tcs.ilp.pharmacy.medisync.repository.UsersRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
public class RfqService {

    private final RfqRepository rfqRepo;
    private final UsersRepository usersRepo;
    private final StoreRepository storeRepo;

    public RfqService(RfqRepository rfqRepo,
                      UsersRepository usersRepo,
                      StoreRepository storeRepo) {
        this.rfqRepo = rfqRepo;
        this.usersRepo = usersRepo;
        this.storeRepo = storeRepo;
    }

    // ---------- READ ----------

    @Transactional(readOnly = true)
    public List<RfqPayloadDto> listAll() {
        return rfqRepo.findAll()
                .stream()
                .map(this::buildPayload)
                .toList();
    }

    @Transactional(readOnly = true)
    public RfqPayloadDto getRfq(Integer rfqId) {
        Rfq rfq = findRfq(rfqId);
        return buildPayload(rfq);
    }

    @Transactional(readOnly = true)
    public List<RfqItemDto> getItems(Integer rfqId) {
        Rfq rfq = findRfq(rfqId);
        return rfq.getItems().stream().map(i -> {
            RfqItemDto dto = new RfqItemDto();
            dto.setRfqItemId(i.getRfqItemId());
            dto.setQuantityNeeded(i.getQuantityNeeded());
            return dto;
        }).toList();
    }

    // ---------- WRITE ----------

    public RfqPayloadDto createRfq(RfqPayloadDto payload) {

        Rfq rfq = new Rfq();
        RfqDto in = payload.getRfq();

        rfq.setStatus(in.getStatusAward());
        rfq.setSubmissionDeadline(in.getSubmissionDeadline());
        rfq.setExpectedDeliveryDate(in.getExpectedDeliveryDate());

        Users creator = usersRepo.findById(in.getCreatedBy())
                .orElseThrow(() -> new NotFoundException("User not found"));

        rfq.setCreatedBy(creator);

        Stores store = storeRepo.findByManager_UserId(creator.getUserId())
                .orElseThrow(() -> new NotFoundException("Store not found"));

        rfq.setStore(store);

        for (RfqItemDto itemDto : payload.getItems()) {
            RfqItems item = new RfqItems();
            item.setQuantityNeeded(itemDto.getQuantityNeeded());
            rfq.getItems().add(item);
        }

        return buildPayload(rfqRepo.save(rfq));
    }

    public RfqPayloadDto updateRfq(Integer rfqId, RfqPayloadDto payload) {

        Rfq existing = findRfq(rfqId);
        RfqDto in = payload.getRfq();

        existing.setStatus(in.getStatusAward());
        existing.setSubmissionDeadline(in.getSubmissionDeadline());
        existing.setExpectedDeliveryDate(in.getExpectedDeliveryDate());

        existing.getItems().clear();
        for (RfqItemDto dto : payload.getItems()) {
            RfqItems item = new RfqItems();
            item.setQuantityNeeded(dto.getQuantityNeeded());
            existing.getItems().add(item);
        }

        return buildPayload(rfqRepo.save(existing));
    }

    public void delete(Integer rfqId) {
        rfqRepo.delete(findRfq(rfqId));
    }

    public void award(Integer rfqId, String status) {
        Rfq rfq = findRfq(rfqId);
        rfq.setStatus(status);
    }

    // ---------- helpers ----------

    private Rfq findRfq(Integer rfqId) {
        return rfqRepo.findById(rfqId)
                .orElseThrow(() -> new NotFoundException("RFQ not found: " + rfqId));
    }

    private RfqPayloadDto buildPayload(Rfq rfq) {

        RfqDto rfqDto = new RfqDto();
        rfqDto.setRfqId(rfq.getRfqId());
        rfqDto.setCreatedBy(rfq.getCreatedBy().getUserId());
        rfqDto.setStatusAward(rfq.getStatus());
        rfqDto.setSubmissionDeadline(rfq.getSubmissionDeadline());
        rfqDto.setExpectedDeliveryDate(rfq.getExpectedDeliveryDate());

        List<RfqItemDto> items = rfq.getItems().stream().map(i -> {
            RfqItemDto dto = new RfqItemDto();
            dto.setRfqItemId(i.getRfqItemId());
            dto.setQuantityNeeded(i.getQuantityNeeded());
            return dto;
        }).toList();

        return new RfqPayloadDto(rfqDto, items);
    }
}
