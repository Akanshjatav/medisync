package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.*;
import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.exception.ConflictException;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.InventoryService;
import com.tcs.ilp.pharmacy.medisync.service.StoreService;
import com.tcs.ilp.pharmacy.medisync.service.UsersService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/ho")
public class HeadOfficeController {

    private final StoreService storeService;
    private final InventoryService inventoryService;
    private final UsersService usersService;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public HeadOfficeController(StoreService storeService,
                                InventoryService inventoryService,
                                UsersService usersService) {
        this.storeService = storeService;
        this.inventoryService = inventoryService;
        this.usersService = usersService;
    }

    // =========================================================
    //                    STORE / BRANCH
    // =========================================================

    /**
     * Inventory is system-created: no inventory input from FE.
     * Atomic: store + inventory in one transaction.
     */
    @PostMapping("/register-branch")
    @Transactional
    public ResponseEntity<StoreCreateResponse> registerBranch(@Valid @RequestBody StoreCreateRequest request) {

        if (request == null) throw new ValidationException("Request body is required");

        Stores exists = storeService.getStoreByStoreName(request.getBranchName());
        if (exists != null) {
            throw new ConflictException("Branch " + exists.getStoreName() + " already exists.");
        }

        Stores store = new Stores();
        store.setStoreName(request.getBranchName().trim());
        store.setLocation(request.getBranchLocation().trim());
        store.setAddress(request.getAddress().trim());

        Stores createdStore = storeService.createStore(store);

        // System function
        Inventory createdInventory = inventoryService.createInventory(createdStore.getStoreId());

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(createdStore.getStoreId())
                .toUri();

        StoreCreateResponse response = new StoreCreateResponse(
                createdStore.getStoreId(),
                createdInventory.getInventoryId(),
                createdStore.getStoreName(),
                createdStore.getLocation(),
                createdStore.getAddress()
        );

        return ResponseEntity.created(location).body(response);
    }

    // =========================================================
    //                          USERS
    // =========================================================
    @GetMapping("/branches")
    public ResponseEntity<List<StoreResponse>> getAllBranches() {

        List<StoreResponse> response = storeService.getAllStores()
                .stream()
                .map(this::toStoreResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }




    @PostMapping("/users")
    public ResponseEntity<UserResponse> createUser(@RequestBody UserCreateRequest request) {
        requireBody(request, "Request body is required");
        validateCreateUser(request);

        Users created = usersService.createUser(request);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getUserId())
                .toUri();

        return ResponseEntity.created(location).body(toUserResponse(created));
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponse> getUser(@PathVariable int id) {
        requirePositive(id, "userId");
        Users u = usersService.getUser(id);
        return ResponseEntity.ok(toUserResponse(u));
    }

    @GetMapping("/users")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        List<UserResponse> out = usersService.getAllUsers()
                .stream()
                .map(this::toUserResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(out);
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<UserResponse> updateUser(@PathVariable int id,
                                                   @RequestBody UserUpdateRequest request) {
        requirePositive(id, "userId");
        requireBody(request, "Request body is required");
        validateUpdateUser(request);

        Users updated = usersService.updateUser(id, request);
        return ResponseEntity.ok(toUserResponse(updated));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
        requirePositive(id, "userId");
        usersService.removeUser(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/branches/{storeId}/inventory")
    public ResponseEntity<BranchInventoryResponse> getBranchInventory(@PathVariable int storeId) {
        if (storeId <= 0) throw new ValidationException("storeId must be positive");
        BranchInventoryResponse response = inventoryService.getBranchInventoryDetails(storeId);
        return ResponseEntity.ok(response);
    }



    @PatchMapping("/users/{id}/deactivate")
    public ResponseEntity<Void> deactivateUser(@PathVariable int id) {
        requirePositive(id, "userId");
        usersService.deactivateUser(id);
        return ResponseEntity.noContent().build();
    }

    // =========================================================
    //                     MAPPER + VALIDATION
    // =========================================================

    private UserResponse toUserResponse(Users u) {
        String roleName = u.getRole() != null ? u.getRole().getRoleName() : null;

        return new UserResponse(
                u.getUserId(),
                roleName,
                u.isActive(),
                u.getName(),
                u.getEmail(),
                u.getPhoneNumber(),
                u.getCreatedAt(),
                u.getUpdatedAt()
        );
    }
    private StoreResponse toStoreResponse(Stores s) {
        return new StoreResponse(
                s.getStoreId(),
                s.getStoreName(),
                s.getLocation(),
                s.getAddress(),
                // remove below 2 if not present in Stores entity
                s.getCreatedAt(),
                s.getUpdatedAt()
        );
    }
    private void validateCreateUser(UserCreateRequest r) {
        requireNotBlank(r.getRoleName(), "roleName is required");
        requireNotBlank(r.getName(), "name is required");
        requireNotBlank(r.getEmail(), "email is required");
        requireEmail(r.getEmail());
        requireNotBlank(r.getPassword(), "password is required");

        if (r.getPhoneNumber() != null && r.getPhoneNumber().length() > 15) {
            throw new ValidationException("phoneNumber must not exceed 15 characters");
        }
    }

    private void validateUpdateUser(UserUpdateRequest r) {
        requireNotBlank(r.getRoleName(), "roleName is required");
        requireNotBlank(r.getName(), "name is required");
        requireNotBlank(r.getEmail(), "email is required");
        requireEmail(r.getEmail());

        if (r.getPhoneNumber() != null && r.getPhoneNumber().length() > 15) {
            throw new ValidationException("phoneNumber must not exceed 15 characters");
        }
        // password optional
    }

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requireNotBlank(String value, String message) {
        if (value == null || value.isBlank()) throw new ValidationException(message);
    }

    private void requireEmail(String email) {
        if (email == null || email.isBlank()) return;
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new ValidationException("email is invalid");
        }
    }
}