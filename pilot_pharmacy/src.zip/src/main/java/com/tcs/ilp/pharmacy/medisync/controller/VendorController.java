package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.*;
import com.tcs.ilp.pharmacy.medisync.service.BidsService;
import com.tcs.ilp.pharmacy.medisync.service.RfqService;
import com.tcs.ilp.pharmacy.medisync.service.VendorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/vendors")
public class VendorController {

    private final VendorService vendorService;
    private final RfqService rfqService;
    private final BidsService bidsService;

    public VendorController(
            VendorService vendorService,
            RfqService rfqService,
            BidsService bidsService
    ) {
        this.vendorService = vendorService;
        this.rfqService = rfqService;
        this.bidsService = bidsService;
    }

    // =====================================================
    // VENDOR PROFILE
    // =====================================================

    @GetMapping
    public ResponseEntity<List<VendorResponse>> getAllVendors() {
        return ResponseEntity.ok(vendorService.getAllVendors());
    }

    @PostMapping("/register")
    public ResponseEntity<VendorResponse> registerVendor(
            @Valid @RequestBody VendorRegisterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(vendorService.registerVendor(request));
    }

    @PostMapping("/{vendorId}/documents")
    public ResponseEntity<VendorDocumentResponse> uploadDocument(
            @PathVariable Integer vendorId,
            @Valid @RequestBody VendorDocumentUploadRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(vendorService.uploadDocument(vendorId, request));
    }

    // =====================================================
    // RFQ BROWSING (READ ONLY)
    // =====================================================

    @GetMapping("/rfqs")
    public List<RfqPayloadDto> getAllRfqs() {
        return rfqService.listAll();
    }

    @GetMapping("/rfqs/{rfqId}")
    public RfqPayloadDto getRfq(@PathVariable Integer rfqId) {
        return rfqService.getRfq(rfqId);
    }

    // =====================================================
    // BIDS
    // =====================================================

    @PostMapping("/bids")
    @ResponseStatus(HttpStatus.CREATED)
    public void createBid(@RequestBody BidRequestDto request) {
        bidsService.createBid(request);
    }

    @GetMapping("/rfqs/{rfqId}/bids")
    public List<BidDto> getBidsForRfq(@PathVariable Integer rfqId) {
        return bidsService.getBidsForRfq(rfqId);
    }

    @PutMapping("/bids/{bidId}/items")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void updateBidItems(
            @PathVariable Integer bidId,
            @RequestBody BidItemsUpdateDto request) {

        bidsService.updateBidItems(bidId, request);
    }

    @DeleteMapping("/bids/{bidId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteBid(@PathVariable Integer bidId) {
        bidsService.delete(bidId);
    }
}
