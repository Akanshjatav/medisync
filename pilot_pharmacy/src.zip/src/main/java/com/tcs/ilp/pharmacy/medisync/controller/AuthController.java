package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.*;
import com.tcs.ilp.pharmacy.medisync.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    // ==========================
    // USER LOGIN
    // ==========================
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> loginUser(
            @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.loginUser(request));
    }

    // ==========================
    // VENDOR LOGIN
    // ==========================
    @PostMapping("/vendor/login")
    public ResponseEntity<VendorLoginResponse> loginVendor(
            @RequestBody VendorLoginRequest request) {
        return ResponseEntity.ok(authService.loginVendor(request));
    }
}
