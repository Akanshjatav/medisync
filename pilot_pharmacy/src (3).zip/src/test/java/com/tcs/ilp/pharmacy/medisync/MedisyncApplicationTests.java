package com.tcs.ilp.pharmacy.medisync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedisyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
