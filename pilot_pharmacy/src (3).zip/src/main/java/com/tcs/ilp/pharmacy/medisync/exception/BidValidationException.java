package com.tcs.ilp.pharmacy.medisync.exception;

public class BidValidationException extends RuntimeException {
    public BidValidationException(String message) {
        super(message);
    }
}
