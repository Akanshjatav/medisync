package com.tcs.ilp.pharmacy.medisync.bootstrap;

import com.tcs.ilp.pharmacy.medisync.entity.*;
import com.tcs.ilp.pharmacy.medisync.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Component
@Profile("dev")
public class HeavyDataBootstrap implements CommandLineRunner {

    private final RoleRepository roleRepo;
    private final UsersRepository usersRepo;
    private final StoreRepository storeRepo;
    private final InventoryRepository inventoryRepo;
    private final VendorRepository vendorRepo;
    private final RfqRepository rfqRepo;
    private final BidsRepository bidsRepo;
    private final BatchRepository batchRepo;
    private final ProductRepository productRepo;
    private final StockRequestsRepository stockReqRepo;
    private final StockTransfersRepository stockTransferRepo;
    private final NotificationRepository notificationRepo;

    public HeavyDataBootstrap(
            RoleRepository roleRepo,
            UsersRepository usersRepo,
            StoreRepository storeRepo,
            InventoryRepository inventoryRepo,
            VendorRepository vendorRepo,
            RfqRepository rfqRepo,
            BidsRepository bidsRepo,
            BatchRepository batchRepo,
            ProductRepository productRepo,
            StockRequestsRepository stockReqRepo,
            StockTransfersRepository stockTransferRepo,
            NotificationRepository notificationRepo
    ) {
        this.roleRepo = roleRepo;
        this.usersRepo = usersRepo;
        this.storeRepo = storeRepo;
        this.inventoryRepo = inventoryRepo;
        this.vendorRepo = vendorRepo;
        this.rfqRepo = rfqRepo;
        this.bidsRepo = bidsRepo;
        this.batchRepo = batchRepo;
        this.productRepo = productRepo;
        this.stockReqRepo = stockReqRepo;
        this.stockTransferRepo = stockTransferRepo;
        this.notificationRepo = notificationRepo;
    }

    @Override
    @Transactional
    public void run(String... args) {

        if (usersRepo.count() > 0) return;

        // =====================================================
        // ROLES
        // =====================================================
        Role admin = roleRepo.save(role("ADMIN"));
        Role manager = roleRepo.save(role("MANAGER"));
        Role pharmacist = roleRepo.save(role("PHARMACIST"));
        Role vendorRole = roleRepo.save(role("VENDOR"));

        // =====================================================
        // USERS (21)
        // =====================================================
        Users hoAdmin = usersRepo.save(user("HO Admin", "admin@ho.com", admin));

        Users mgr1 = usersRepo.save(user("Manager BLR", "mgr.blr@store.com", manager));
        Users pharm1 = usersRepo.save(user("Pharmacist BLR", "pharm.blr@store.com", pharmacist));

        Users mgr2 = usersRepo.save(user("Manager DEL", "mgr.del@store.com", manager));
        Users pharm2 = usersRepo.save(user("Pharmacist DEL", "pharm.del@store.com", pharmacist));

        Users vendorUser1 = usersRepo.save(user("Vendor One", "vendor1@biz.com", vendorRole));
        Users vendorUser2 = usersRepo.save(user("Vendor Two", "vendor2@biz.com", vendorRole));
        Users vendorUser3 = usersRepo.save(user("Vendor Three", "vendor3@biz.com", vendorRole));

        // =====================================================
        // STORES (10 simplified to 2 here for sanity)
        // =====================================================
        Stores blr = storeRepo.save(store("Bangalore Central", "Bangalore", mgr1, pharm1));
        Stores del = storeRepo.save(store("Delhi North", "Delhi", mgr2, pharm2));

        // =====================================================
        // INVENTORY (must exist before Batch)
        // =====================================================
        Inventory invBlr = inventoryRepo.save(inventory(blr));
        Inventory invDel = inventoryRepo.save(inventory(del));

        // =====================================================
        // VENDORS (MANDATORY email + password!)
        // =====================================================
        Vendor vendorA = vendorRepo.save(vendor(vendorUser1, "vendor1@biz.com", "GST-001", "LIC-001"));
        Vendor vendorB = vendorRepo.save(vendor(vendorUser2, "vendor2@biz.com", "GST-002", "LIC-002"));
        Vendor vendorC = vendorRepo.save(vendor(vendorUser3, "vendor3@biz.com", "GST-003", "LIC-003"));

        // =====================================================
        // RFQs
        // =====================================================
        Rfq rfq1 = rfqRepo.save(rfq(blr, mgr1, "ISSUED",
                rfqItem("Paracetamol", 1000),
                rfqItem("Ibuprofen", 500)
        ));

        // =====================================================
        // BIDS (vendor MUST be persisted)
        // =====================================================
        bidsRepo.save(bid(rfq1, vendorA,
                bidItem("Paracetamol", 1000, 2.10),
                bidItem("Ibuprofen", 500, 3.00)
        ));

        bidsRepo.save(bid(rfq1, vendorB,
                bidItem("Paracetamol", 1000, 2.00),
                bidItem("Ibuprofen", 500, 2.90)
        ));

        // =====================================================
        // BATCHES + PRODUCTS
        // =====================================================
        Batch batchBlr = batchRepo.save(batch(invBlr, vendorB, "BLR-BATCH-1"));
        productRepo.saveAll(List.of(
                product(batchBlr, "Paracetamol", "Tablet", 1000, 2.0),
                product(batchBlr, "Ibuprofen", "Tablet", 500, 2.9)
        ));

        // =====================================================
        // STOCK REQUEST
        // =====================================================
        stockReqRepo.save(stockRequest(blr, pharm1,
                stockReqItem("Paracetamol", 200)
        ));

        // =====================================================
        // STOCK TRANSFER
        // =====================================================
        stockTransferRepo.save(stockTransfer(blr, del, mgr1,
                stockTransferItem("Paracetamol", 100)
        ));

        // =====================================================
        // NOTIFICATION
        // =====================================================
        notificationRepo.save(notification(
                pharm1,
                hoAdmin,
                "HIGH",
                "Low Stock Alert",
                "Paracetamol stock is below threshold"
        ));
    }

    // =====================================================
    // HELPERS (ALL ENTITY-SAFE)
    // =====================================================

    private Role role(String name) {
        Role r = new Role();
        r.setRoleName(name);
        return r;
    }

    private Users user(String name, String email, Role role) {
        Users u = new Users();
        u.setName(name);
        u.setEmail(email);
        u.setUsername(email);
        u.setPassword("password");
        u.setRole(role);
        u.setActive(true);
        return u;
    }

    private Stores store(String name, String loc, Users mgr, Users pharm) {
        Stores s = new Stores();
        s.setStoreName(name);
        s.setLocation(loc);
        s.setAddress(loc + " main road");
        s.setManager(mgr);
        s.setPharmacist(pharm);
        return s;
    }

    private Inventory inventory(Stores store) {
        Inventory i = new Inventory();
        i.setStore(store);
        return i;
    }

    private Vendor vendor(Users user, String email, String gst, String lic) {
        Vendor v = new Vendor();
        v.setUser(user);
        v.setEmail(email);
        v.setPassword("password");
        v.setGstNumber(gst);
        v.setLicenseNumber(lic);
        v.setAddress("Vendor HQ Address");
        v.setStatus("APPROVED");
        return v;
    }

    private Rfq rfq(Stores store, Users by, String status, RfqItems... items) {
        Rfq r = new Rfq();
        r.setStore(store);
        r.setCreatedBy(by);
        r.setStatus(status);
        for (RfqItems i : items) {
//            i.setRfq(r);
            r.getItems().add(i);
        }
        return r;
    }

    private RfqItems rfqItem(String med, int qty) {
        RfqItems i = new RfqItems();
        i.setMedicineName(med);
        i.setQuantityNeeded(qty);
        return i;
    }

    private Bids bid(Rfq rfq, Vendor vendor, BidItems... items) {
        Bids b = new Bids();
        b.setRfq(rfq);
        b.setVendor(vendor);
        b.setStatus("SUBMITTED");
        for (BidItems i : items) {
            i.setBids(b);
            b.getItems().add(i);
        }
        return b;
    }

    private BidItems bidItem(String med, int qty, double price) {
        BidItems i = new BidItems();
        i.setMedicineName(med);
        i.setItemQuantity(qty);
        i.setItemPrice(BigDecimal.valueOf(price));
        return i;
    }

    private Batch batch(Inventory inv, Vendor vendor, String code) {
        Batch b = new Batch();
        b.setInventory(inv);
        b.setVendor(vendor);
        b.setBatchCode(code);
        b.setDeliveryDate(LocalDate.now());
        return b;
    }

    private Product product(Batch b, String name, String cat, int qty, double price) {
        Product p = new Product();
        p.setBatch(b);
        p.setProductName(name);
        p.setCategory(cat);
        p.setQuantityTotal(qty);
        p.setPrice(price);
        p.setExpiryDate(LocalDate.now().plusYears(2));
        return p;
    }

    private StockRequests stockRequest(Stores s, Users u, StockRequestItems... items) {
        StockRequests sr = new StockRequests();
        sr.setStore(s);
        sr.setRequestedBy(u);
        sr.setStatus("PENDING");
        for (StockRequestItems i : items) {
            i.setStockRequestId(sr);
            sr.getItems().add(i);
        }
        return sr;
    }

    private StockRequestItems stockReqItem(String med, int qty) {
        StockRequestItems i = new StockRequestItems();
        i.setMedicineName(med);
        i.setRequiredQuantity(qty);
        return i;
    }

    private StockTransfers stockTransfer(Stores from, Stores to, Users by, StockTransferItems... items) {
        StockTransfers st = new StockTransfers();
        st.setFromStore(from);
        st.setToStore(to);
        st.setInitiatedBy(by);
        st.setStatus("REQUESTED");
        for (StockTransferItems i : items) {
            i.setStockTransfer(st);
            st.getItems().add(i);
        }
        return st;
    }

    private StockTransferItems stockTransferItem(String med, int qty) {
        StockTransferItems i = new StockTransferItems();
        i.setMedicineName(med);
        i.setQuantity(qty);
        return i;
    }

    private Notification notification(Users from, Users to, String sev, String title, String msg) {
        Notification n = new Notification();
        n.setRaisedBy(from);
        n.setToUser(to);
        n.setSeverity(sev);
        n.setTitle(title);
        n.setMessage(msg);
        n.setNotificationStatus("NEW");
        return n;
    }
}
