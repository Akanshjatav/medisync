package com.tcs.ilp.pharmacy.medisync.service;
import com.tcs.ilp.pharmacy.medisync.service.RfqService;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.RfqItems;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.RfqRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RfqServiceTest {

    @Mock
    private RfqRepository repo;

    @InjectMocks
    private RfqService service;

    private Rfq rfq;
    private List<RfqItems> items;

    @BeforeEach
    void setUp() {
        rfq = new Rfq();
        rfq.setRfqId(1);
        rfq.setCreatedBy(101);
        rfq.setStatusAward("PENDING");
        rfq.setSubmissionDeadline(LocalDateTime.of(2026, 2, 1, 18, 0));
        rfq.setExpectedDeliveryDate(LocalDateTime.of(2026, 2, 10, 0, 0));

        RfqItems it1 = new RfqItems();
        it1.setRfqItemId(10);
        it1.setRfqId(1);
        it1.setQuantityNeeded(50);

        RfqItems it2 = new RfqItems();
        it2.setRfqItemId(11);
        it2.setRfqId(1);
        it2.setQuantityNeeded(100);

        items = List.of(it1, it2);
    }

    // -------------------- READ --------------------

    @Test
    void listAll_returnsHeaders() {
        when(repo.findAllRfqHeaders()).thenReturn(List.of(rfq));

        List<Rfq> result = service.listAll();

        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getRfqId());
        verify(repo).findAllRfqHeaders();
        verifyNoMoreInteractions(repo);
    }

    @Test
    void getRfq_whenExists_returnsEntity() {
        when(repo.findByRfqId(1)).thenReturn(Optional.of(rfq));

        Rfq result = service.getRfq(1);

        assertEquals(1, result.getRfqId());
        verify(repo).findByRfqId(1);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void getRfq_whenMissing_throwsNotFound() {
        when(repo.findByRfqId(999)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class, () -> service.getRfq(999));
        assertTrue(ex.getMessage().contains("999"));
        verify(repo).findByRfqId(999);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void getItems_returnsListPossiblyEmpty() {
        when(repo.findItemsByRfqId(1)).thenReturn(items);

        List<RfqItems> res = service.getItems(1);

        assertEquals(2, res.size());
        verify(repo).findItemsByRfqId(1);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void listByCreatedBy_returnsList() {
        when(repo.findByCreatedBy(101)).thenReturn(List.of(rfq));

        List<Rfq> res = service.listByCreatedBy(101);

        assertEquals(1, res.size());
        verify(repo).findByCreatedBy(101);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- WRITE --------------------

    @Test
    void createWithItems_delegatesToRepo_andReturnsId() {
        when(repo.createWithItems(any(Rfq.class), anyList())).thenReturn(123);

        int newId = service.createWithItems(rfq, items);

        assertEquals(123, newId);
        verify(repo).createWithItems(rfq, items);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void updateWithItems_whenExists_locksAndUpdates() {
        when(repo.findByRfqIdForUpdate(1)).thenReturn(Optional.of(rfq));
        when(repo.updateWithItems(any(Rfq.class), anyList())).thenReturn(true);

        assertDoesNotThrow(() -> service.updateWithItems(rfq, items));

        verify(repo).findByRfqIdForUpdate(1);
        verify(repo).updateWithItems(rfq, items);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void updateWithItems_whenMissing_throwsNotFound_andDoesNotCallUpdate() {
        when(repo.findByRfqIdForUpdate(1)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.updateWithItems(rfq, items));

        verify(repo).findByRfqIdForUpdate(1);
        verify(repo, never()).updateWithItems(any(), anyList());
        verifyNoMoreInteractions(repo);
    }

    @Test
    void updateWithItems_whenRepoReturnsFalse_defensiveNotFound() {
        when(repo.findByRfqIdForUpdate(1)).thenReturn(Optional.of(rfq));
        when(repo.updateWithItems(any(Rfq.class), anyList())).thenReturn(false);

        assertThrows(NotFoundException.class, () -> service.updateWithItems(rfq, items));

        verify(repo).findByRfqIdForUpdate(1);
        verify(repo).updateWithItems(rfq, items);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void deleteCascade_whenDeleted_ok() {
        when(repo.deleteCascade(1)).thenReturn(true);

        assertDoesNotThrow(() -> service.deleteCascade(1));

        verify(repo).deleteCascade(1);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void deleteCascade_whenMissing_throwsNotFound() {
        when(repo.deleteCascade(404)).thenReturn(false);

        assertThrows(NotFoundException.class, () -> service.deleteCascade(404));

        verify(repo).deleteCascade(404);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- DOMAIN ACTION: award --------------------

    @Test
    void award_whenExists_updatesStatusAndPersistsWithSameItems() {
        when(repo.findByRfqIdForUpdate(1)).thenReturn(Optional.of(rfq));
        when(repo.findItemsByRfqId(1)).thenReturn(items);
        when(repo.updateWithItems(any(Rfq.class), anyList())).thenReturn(true);

        service.award(1, "AWARDED");

        ArgumentCaptor<Rfq> rfqCap = ArgumentCaptor.forClass(Rfq.class);
        verify(repo).updateWithItems(rfqCap.capture(), eq(items));
        Rfq updated = rfqCap.getValue();

        assertEquals("AWARDED", updated.getStatusAward());
        verify(repo).findByRfqIdForUpdate(1);
        verify(repo).findItemsByRfqId(1);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void award_whenMissing_throwsNotFound() {
        when(repo.findByRfqIdForUpdate(999)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.award(999, "AWARDED"));

        verify(repo).findByRfqIdForUpdate(999);
        verify(repo, never()).findItemsByRfqId(anyInt());
        verify(repo, never()).updateWithItems(any(), anyList());
        verifyNoMoreInteractions(repo);
    }

    @Test
    void award_whenUpdateReturnsFalse_defensiveNotFound() {
        when(repo.findByRfqIdForUpdate(1)).thenReturn(Optional.of(rfq));
        when(repo.findItemsByRfqId(1)).thenReturn(items);
        when(repo.updateWithItems(any(Rfq.class), anyList())).thenReturn(false);

        assertThrows(NotFoundException.class, () -> service.award(1, "AWARDED"));

        verify(repo).findByRfqIdForUpdate(1);
        verify(repo).findItemsByRfqId(1);
        verify(repo).updateWithItems(any(Rfq.class), eq(items));
        verifyNoMoreInteractions(repo);
    }
}

