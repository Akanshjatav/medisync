
package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.repository.StoreRepository;
import com.tcs.ilp.pharmacy.medisync.service.StoreService;
import com.tcs.ilp.pharmacy.medisync.exception.StoreNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.*;
import static org.mockito.Mockito.never;

@ExtendWith(MockitoExtension.class)
class StoreServiceTest {

    @Mock
    private StoreRepository repo;

    @InjectMocks
    private StoreService service;

    private Stores mkStore(Integer id,
                           String location,
                           Integer managerId,
                           Integer pharmacistId,
                           LocalDateTime createdAt) {
        Stores s = new Stores();
        s.setStoreId(id);
        s.setLocation(location);
        s.setManagerId(managerId);
        s.setPharmacistId(pharmacistId);
        s.setCreatedAt(createdAt);
        return s;
    }

    private final LocalDateTime NOW = LocalDateTime.of(2026, 1, 23, 10, 30, 0);

    @Nested
    @DisplayName("createStore")
    class CreateStore {

        @Test
        @DisplayName("should create and return saved store")
        void create_ok() {
            Stores incoming = mkStore(null, "Trivandrum", 101, 201, null);
            Stores saved = mkStore(1, "Trivandrum", 101, 201, NOW);

            given(repo.save(any(Stores.class))).willReturn(saved);

            Stores result = service.createStore(incoming);

            assertNotNull(result);
            assertEquals(1, result.getStoreId());
            assertEquals("Trivandrum", result.getLocation());
            assertEquals(101, result.getManagerId());
            assertEquals(201, result.getPharmacistId());
            assertEquals(NOW, result.getCreatedAt());

            then(repo).should().save(any(Stores.class));
        }

        @Test
        @DisplayName("should fail when location is null")
        void create_locationNull() {
            Stores incoming = mkStore(null, null, 101, 201, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createStore(incoming));
            assertEquals("location is required", ex.getMessage());

            then(repo).should(never()).save(any());
        }

        @Test
        @DisplayName("should fail when location is blank")
        void create_locationBlank() {
            Stores incoming = mkStore(null, "   ", 101, 201, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createStore(incoming));
            assertEquals("location is required", ex.getMessage());

            then(repo).should(never()).save(any());
        }

        @Test
        @DisplayName("should fail when managerId is null")
        void create_managerNull() {
            Stores incoming = mkStore(null, "TVM", null, 201, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createStore(incoming));
            assertEquals("managerId is required", ex.getMessage());

            then(repo).should(never()).save(any());
        }

        @Test
        @DisplayName("should fail when pharmacistId is null")
        void create_pharmacistNull() {
            Stores incoming = mkStore(null, "TVM", 101, null, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createStore(incoming));
            assertEquals("pharmacistId is required", ex.getMessage());

            then(repo).should(never()).save(any());
        }

        @Test
        @DisplayName("should propagate DataAccessException from repository")
        void create_dbError() {
            Stores incoming = mkStore(null, "TVM", 101, 201, null);
            given(repo.save(any())).willThrow(new DataIntegrityViolationException("duplicate"));

            assertThrows(DataIntegrityViolationException.class, () -> service.createStore(incoming));
            then(repo).should().save(any());
        }
    }

    @Nested
    @DisplayName("getStoreById")
    class GetById {

        @Test
        @DisplayName("should return store when found")
        void get_found() {
            Stores s = mkStore(10, "Kazhakoottam", 100, 200, NOW);
            given(repo.findById(10)).willReturn(Optional.of(s));

            Stores result = service.getStoreById(10);

            assertNotNull(result);
            assertEquals(10, result.getStoreId());
            assertEquals("Kazhakoottam", result.getLocation());
            then(repo).should().findById(10);
        }

        @Test
        @DisplayName("should throw StoreNotFoundException when not found")
        void get_notFound() {
            given(repo.findById(99)).willReturn(Optional.empty());

            StoreNotFoundException ex = assertThrows(StoreNotFoundException.class,
                    () -> service.getStoreById(99));
            assertTrue(ex.getMessage().contains("Store not found with id: 99"));

            then(repo).should().findById(99);
        }
    }

    @Nested
    @DisplayName("getAllStores")
    class GetAll {

        @Test
        @DisplayName("should return all stores")
        void all_ok() {
            given(repo.findAll()).willReturn(List.of(
                    mkStore(1, "TVM", 1, 2, NOW),
                    mkStore(2, "Kochi", 3, 4, NOW)
            ));

            List<Stores> result = service.getAllStores();

            assertEquals(2, result.size());
            then(repo).should().findAll();
        }
    }

    @Nested
    @DisplayName("updateStore")
    class Update {

        @Test
        @DisplayName("should update store and preserve createdAt from existing")
        void update_ok_preserveCreatedAt() {
            int id = 5;
            Stores existing = mkStore(id, "Old", 11, 21, NOW);
            Stores incoming = mkStore(null, "New", 12, 22, null); // createdAt provided by caller should be ignored

            given(repo.findById(id)).willReturn(Optional.of(existing));

            // Capture the object passed to repo.update to assert createdAt & id are set by service
            ArgumentCaptor<Stores> captor = ArgumentCaptor.forClass(Stores.class);

            Stores returned = mkStore(id, "New", 12, 22, NOW); // repo returns updated record (same createdAt)
            given(repo.update(any(Stores.class))).willReturn(returned);

            Stores result = service.updateStore(id, incoming);

            assertNotNull(result);
            assertEquals(id, result.getStoreId());
            assertEquals("New", result.getLocation());
            assertEquals(12, result.getManagerId());
            assertEquals(22, result.getPharmacistId());
            assertEquals(NOW, result.getCreatedAt());

            then(repo).should().findById(id);
            then(repo).should().update(captor.capture());

            Stores passed = captor.getValue();
            assertEquals(id, passed.getStoreId(), "Service should set path id on entity");
            assertEquals("New", passed.getLocation());
            assertEquals(12, passed.getManagerId());
            assertEquals(22, passed.getPharmacistId());
            assertEquals(NOW, passed.getCreatedAt(), "createdAt must be preserved from existing entity");
        }

        @Test
        @DisplayName("should throw not found when target id does not exist")
        void update_notFound() {
            given(repo.findById(77)).willReturn(Optional.empty());
            Stores incoming = mkStore(null, "Any", 1, 2, null);

            StoreNotFoundException ex = assertThrows(StoreNotFoundException.class,
                    () -> service.updateStore(77, incoming));
            assertTrue(ex.getMessage().contains("Store not found with id: 77"));

            then(repo).should().findById(77);
            then(repo).should(never()).update(any());
        }

        @Test
        @DisplayName("should validate location is required")
        void update_locationBlank() {
            int id = 9;
            Stores existing = mkStore(id, "Old", 1, 2, NOW);
            given(repo.findById(id)).willReturn(Optional.of(existing));

            Stores incoming = mkStore(null, "   ", 1, 2, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateStore(id, incoming));
            assertEquals("location is required", ex.getMessage());

            then(repo).should().findById(id);
            then(repo).should(never()).update(any());
        }

        @Test
        @DisplayName("should validate managerId is required")
        void update_managerNull() {
            int id = 9;
            Stores existing = mkStore(id, "Old", 1, 2, NOW);
            given(repo.findById(id)).willReturn(Optional.of(existing));

            Stores incoming = mkStore(null, "New", null, 2, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateStore(id, incoming));
            assertEquals("managerId is required", ex.getMessage());

            then(repo).should().findById(id);
            then(repo).should(never()).update(any());
        }

        @Test
        @DisplayName("should validate pharmacistId is required")
        void update_pharmacistNull() {
            int id = 9;
            Stores existing = mkStore(id, "Old", 1, 2, NOW);
            given(repo.findById(id)).willReturn(Optional.of(existing));

            Stores incoming = mkStore(null, "New", 1, null, null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateStore(id, incoming));
            assertEquals("pharmacistId is required", ex.getMessage());

            then(repo).should().findById(id);
            then(repo).should(never()).update(any());
        }
    }

    @Nested
    @DisplayName("deleteStore")
    class Delete {

        @Test
        @DisplayName("should delete when repository returns true")
        void delete_ok() {
            given(repo.deleteById(5)).willReturn(true);

            assertDoesNotThrow(() -> service.deleteStore(5));

            then(repo).should().deleteById(5);
        }

        @Test
        @DisplayName("should throw not found when repository returns false")
        void delete_notFound() {
            given(repo.deleteById(55)).willReturn(false);

            StoreNotFoundException ex = assertThrows(StoreNotFoundException.class,
                    () -> service.deleteStore(55));
            assertTrue(ex.getMessage().contains("Store not found with id: 55"));

            then(repo).should().deleteById(55);
        }
    }

    @Nested
    @DisplayName("exists")
    class Exists {

        @Test
        @DisplayName("should return true/false from repository")
        void exists_ok() {
            given(repo.exists(3)).willReturn(true);
            assertTrue(service.exists(3));
            then(repo).should().exists(3);

            given(repo.exists(4)).willReturn(false);
            assertFalse(service.exists(4));
            then(repo).should().exists(4);
        }
    }

    @Nested
    @DisplayName("searchByLocation")
    class Search {

        @Test
        @DisplayName("should delegate to repository")
        void search_ok() {
            given(repo.searchByLocation("tvm")).willReturn(List.of(
                    mkStore(1, "Trivandrum", 1, 2, NOW)
            ));

            List<Stores> result = service.searchByLocation("tvm");

            assertEquals(1, result.size());
            assertEquals("Trivandrum", result.get(0).getLocation());

            then(repo).should().searchByLocation("tvm");
        }
    }
}

