package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.BidItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidItemsUpdateDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidRequestDto;
import com.tcs.ilp.pharmacy.medisync.entity.BidItems;
import com.tcs.ilp.pharmacy.medisync.entity.Bids;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.Vendor;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.exception.ResourceNotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.BidsRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * DTO-aware tests for BidsService using Mockito (JUnit 5).
 */
@ExtendWith(MockitoExtension.class)
class BidsServiceTest {

    @Mock
    private BidsRepository repo;

    @InjectMocks
    private BidsService service;

    private Rfq sampleRfq;
    private Vendor sampleVendor;
    private Bids sampleBid;

    @BeforeEach
    void setUp() {
        sampleRfq = new Rfq();
        sampleRfq.setRfqId(10);
        sampleRfq.setCreatedBy(100);
        sampleRfq.setStatusAward("OPEN");
        sampleRfq.setSubmissionDeadline(LocalDateTime.now().plusDays(3));
        sampleRfq.setExpectedDeliveryDate(LocalDateTime.now().plusDays(10));

        sampleVendor = new Vendor();
        sampleVendor.setVendorId(20);
        sampleVendor.setUserId(new Users(200));
        sampleVendor.setGstNumber("GST123");
        sampleVendor.setLicenseNumber("LIC456");
        sampleVendor.setAddress("Trivandrum");
        sampleVendor.setStatus("ACTIVE");

        sampleBid = new Bids();
        sampleBid.setBidId(1);
        sampleBid.setRfq(sampleRfq);
        sampleBid.setVendor(sampleVendor);
        sampleBid.setCreatedAt(LocalDateTime.now());
        sampleBid.setItems(new ArrayList<>());
    }

    // ==========================================================
    // CREATE (DTO)
    // ==========================================================
    @Nested
    class CreateBidDtoTests {

        @Test
        @DisplayName("createBid(dto): happy path maps vendorId/rfqId/items and saves")
        void createBid_ok() {
            BidItemDto itemDto = new BidItemDto();
            itemDto.setItemPrice(new BigDecimal("25.50"));
            itemDto.setItemQuantity(5);

            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);
            dto.setItems(List.of(itemDto));

            when(repo.save(any(Bids.class))).thenAnswer(invocation -> {
                Bids arg = invocation.getArgument(0);
                arg.setBidId(99);
                return arg;
            });

            Bids saved = service.createBid(dto);

            assertNotNull(saved);
            assertEquals(99, saved.getBidId());
            verify(repo, times(1)).save(any(Bids.class));

            // Verify mapping vendorId/rfqId/items
            ArgumentCaptor<Bids> captor = ArgumentCaptor.forClass(Bids.class);
            verify(repo).save(captor.capture());
            Bids passed = captor.getValue();

            assertNotNull(passed.getVendor());
            assertEquals(20, passed.getVendor().getVendorId());

            assertNotNull(passed.getRfq());
            assertEquals(10, passed.getRfq().getRfqId());

            assertNotNull(passed.getItems());
            assertEquals(1, passed.getItems().size());
            assertEquals(5, passed.getItems().get(0).getItemQuantity());
            assertEquals(new BigDecimal("25.50"), passed.getItems().get(0).getItemPrice());
        }

        @Test
        @DisplayName("createBid(dto): allows null items (creates bid header only)")
        void createBid_nullItems_ok() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);
            dto.setItems(null);

            when(repo.save(any(Bids.class))).thenAnswer(invocation -> {
                Bids arg = invocation.getArgument(0);
                arg.setBidId(77);
                return arg;
            });

            Bids saved = service.createBid(dto);

            assertNotNull(saved);
            assertEquals(77, saved.getBidId());
            verify(repo).save(any(Bids.class));
        }

        @Test
        @DisplayName("createBid(dto): rejects null request")
        void createBid_nullDto() {
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createBid(null));
            assertTrue(ex.getMessage().contains("Request cannot be null"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("createBid(dto): vendorId must be > 0")
        void createBid_badVendorId() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(0);
            dto.setRfqId(10);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createBid(dto));
            assertTrue(ex.getMessage().contains("vendorId must be > 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("createBid(dto): rfqId must be > 0")
        void createBid_badRfqId() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(-1);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createBid(dto));
            assertTrue(ex.getMessage().contains("rfqId must be > 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("createBid(dto): itemQuantity must be > 0")
        void createBid_badItemQuantity() {
            BidItemDto itemDto = new BidItemDto();
            itemDto.setItemPrice(new BigDecimal("1.00"));
            itemDto.setItemQuantity(0);

            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);
            dto.setItems(List.of(itemDto));

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createBid(dto));
            assertTrue(ex.getMessage().contains("itemQuantity must be > 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("createBid(dto): itemPrice must be >= 0")
        void createBid_badItemPrice() {
            BidItemDto itemDto = new BidItemDto();
            itemDto.setItemPrice(new BigDecimal("-0.01"));
            itemDto.setItemQuantity(1);

            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);
            dto.setItems(List.of(itemDto));

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.createBid(dto));
            assertTrue(ex.getMessage().contains("itemPrice must be >= 0"));
            verifyNoInteractions(repo);
        }
    }

    // ==========================================================
    // UPDATE HEADER (DTO)
    // ==========================================================
    @Nested
    class UpdateHeaderDtoTests {

        @Test
        @DisplayName("updateBidHeader(dto): happy path calls updateBidHeader and reloads bid")
        void updateBidHeader_ok() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);

            when(repo.updateBidHeader(1, 10, 20)).thenReturn(true);
            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));

            Bids result = service.updateBidHeader(1, dto);

            assertNotNull(result);
            assertEquals(1, result.getBidId());
            verify(repo).updateBidHeader(1, 10, 20);
            verify(repo).findById(1);
        }

        @Test
        @DisplayName("updateBidHeader(dto): throws when update target not found")
        void updateBidHeader_notFound() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);

            when(repo.updateBidHeader(404, 10, 20)).thenReturn(false);

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.updateBidHeader(404, dto));
            assertTrue(ex.getMessage().contains("Bid 404 not found"));

            verify(repo).updateBidHeader(404, 10, 20);
            verify(repo, never()).findById(anyInt());
        }

        @Test
        @DisplayName("updateBidHeader(dto): bidId must be > 0")
        void updateBidHeader_badBidId() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(20);
            dto.setRfqId(10);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidHeader(0, dto));
            assertTrue(ex.getMessage().contains("bidId must be > 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("updateBidHeader(dto): rejects null request")
        void updateBidHeader_nullDto() {
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidHeader(1, null));
            assertTrue(ex.getMessage().contains("Request cannot be null"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("updateBidHeader(dto): vendorId and rfqId must be > 0")
        void updateBidHeader_badIds() {
            BidRequestDto dto = new BidRequestDto();
            dto.setVendorId(0);
            dto.setRfqId(0);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidHeader(1, dto));
            assertTrue(ex.getMessage().contains("vendorId must be > 0")
                    || ex.getMessage().contains("rfqId must be > 0"));

            verifyNoInteractions(repo);
        }
    }

    // ==========================================================
    // REPLACE ITEMS (DTO)
    // ==========================================================
    @Nested
    class ReplaceItemsDtoTests {

        @Test
        @DisplayName("replaceBidItems(dto): replaces items and saves")
        void replaceItems_ok() {
            BidItemDto itemDto = new BidItemDto();
            itemDto.setItemPrice(new BigDecimal("9.99"));
            itemDto.setItemQuantity(2);

            BidItemsUpdateDto dto = new BidItemsUpdateDto();
            dto.setItems(List.of(itemDto));

            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));
            when(repo.save(any(Bids.class))).thenAnswer(invocation -> invocation.getArgument(0));

            Bids saved = service.replaceBidItems(1, dto);

            assertNotNull(saved);
            assertEquals(1, saved.getBidId());
            verify(repo).findById(1);
            verify(repo).save(any(Bids.class));

            ArgumentCaptor<Bids> captor = ArgumentCaptor.forClass(Bids.class);
            verify(repo).save(captor.capture());
            Bids passed = captor.getValue();

            // It should keep vendor/rfq from existing bid
            assertNotNull(passed.getVendor());
            assertEquals(20, passed.getVendor().getVendorId());
            assertNotNull(passed.getRfq());
            assertEquals(10, passed.getRfq().getRfqId());

            // Items replaced
            assertNotNull(passed.getItems());
            assertEquals(1, passed.getItems().size());
            assertEquals(2, passed.getItems().get(0).getItemQuantity());
            assertEquals(new BigDecimal("9.99"), passed.getItems().get(0).getItemPrice());
        }

        @Test
        @DisplayName("replaceBidItems(dto): allows empty items list to clear items")
        void replaceItems_emptyList_clears() {
            BidItemsUpdateDto dto = new BidItemsUpdateDto();
            dto.setItems(Collections.emptyList());

            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));
            when(repo.save(any(Bids.class))).thenAnswer(invocation -> invocation.getArgument(0));

            Bids saved = service.replaceBidItems(1, dto);

            assertNotNull(saved);
            verify(repo).findById(1);
            verify(repo).save(any(Bids.class));

            ArgumentCaptor<Bids> captor = ArgumentCaptor.forClass(Bids.class);
            verify(repo).save(captor.capture());
            assertNotNull(captor.getValue().getItems());
            assertTrue(captor.getValue().getItems().isEmpty());
        }

        @Test
        @DisplayName("replaceBidItems(dto): throws when bid does not exist")
        void replaceItems_bidNotFound() {
            BidItemsUpdateDto dto = new BidItemsUpdateDto();
            dto.setItems(Collections.emptyList());

            when(repo.findById(404)).thenReturn(Optional.empty());

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.replaceBidItems(404, dto));
            assertTrue(ex.getMessage().contains("Bid 404 not found"));

            verify(repo).findById(404);
            verify(repo, never()).save(any());
        }

        @Test
        @DisplayName("replaceBidItems(dto): rejects null request")
        void replaceItems_nullDto() {
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.replaceBidItems(1, null));
            assertTrue(ex.getMessage().contains("Request cannot be null"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("replaceBidItems(dto): rejects null items field")
        void replaceItems_nullItemsField() {
            BidItemsUpdateDto dto = new BidItemsUpdateDto();
            dto.setItems(null);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.replaceBidItems(1, dto));
            assertTrue(ex.getMessage().contains("items must be provided"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("replaceBidItems(dto): validates itemQuantity and itemPrice")
        void replaceItems_validation() {
            BidItemDto bad = new BidItemDto();
            bad.setItemQuantity(0);
            bad.setItemPrice(new BigDecimal("-1.00"));

            BidItemsUpdateDto dto = new BidItemsUpdateDto();
            dto.setItems(List.of(bad));

            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.replaceBidItems(1, dto));
            assertTrue(ex.getMessage().contains("itemQuantity must be > 0")
                    || ex.getMessage().contains("itemPrice must be >= 0"));

            verify(repo).findById(1);
            verify(repo, never()).save(any());
        }
    }

    // ==========================================================
    // READS
    // ==========================================================
    @Nested
    class ReadTests {

        @Test
        @DisplayName("getBidById: returns bid when present")
        void getBidById_ok() {
            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));
            Bids got = service.getBidById(1);
            assertEquals(1, got.getBidId());
            verify(repo).findById(1);
        }

        @Test
        @DisplayName("getBidById: throws ResourceNotFound when missing")
        void getBidById_notFound() {
            when(repo.findById(123)).thenReturn(Optional.empty());
            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.getBidById(123));
            assertTrue(ex.getMessage().contains("Bid 123 not found"));
            verify(repo).findById(123);
        }

        @Test
        @DisplayName("getAllBids: delegates to repository")
        void getAllBids_ok() {
            when(repo.findAll()).thenReturn(List.of(sampleBid));
            List<Bids> list = service.getAllBids();
            assertEquals(1, list.size());
            verify(repo).findAll();
        }

        @Test
        @DisplayName("getBidsByVendor: delegates to repository")
        void getBidsByVendor_ok() {
            when(repo.findByVendorId(20)).thenReturn(List.of(sampleBid));
            List<Bids> list = service.getBidsByVendor(20);
            assertEquals(1, list.size());
            verify(repo).findByVendorId(20);
        }

        @Test
        @DisplayName("getBidsByRfq: delegates to repository")
        void getBidsByRfq_ok() {
            when(repo.findByRfqId(10)).thenReturn(List.of(sampleBid));
            List<Bids> list = service.getBidsByRfq(10);
            assertEquals(1, list.size());
            verify(repo).findByRfqId(10);
        }

        @Test
        @DisplayName("getBidItemsByBidId: checks bid existence then returns items")
        void getBidItemsByBidId_ok() {
            BidItems item = new BidItems();
            item.setBidItemId(1);
            item.setBidId(1);
            item.setItemPrice(new BigDecimal("25.50"));
            item.setItemQuantity(5);

            when(repo.findById(1)).thenReturn(Optional.of(sampleBid));
            when(repo.findBidItemsByBidId(1)).thenReturn(List.of(item));

            List<BidItems> items = service.getBidItemsByBidId(1);
            assertEquals(1, items.size());
            assertEquals(new BigDecimal("25.50"), items.get(0).getItemPrice());

            verify(repo).findById(1);
            verify(repo).findBidItemsByBidId(1);
        }

        @Test
        @DisplayName("getBidItemsByBidId: throws when bid missing")
        void getBidItemsByBidId_notFound() {
            when(repo.findById(999)).thenReturn(Optional.empty());

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.getBidItemsByBidId(999));
            assertTrue(ex.getMessage().contains("Bid 999 not found"));

            verify(repo).findById(999);
            verify(repo, never()).findBidItemsByBidId(anyInt());
        }
    }

    // ==========================================================
    // UPDATE BID ITEM
    // ==========================================================
    @Nested
    class UpdateBidItemTests {

        @Test
        @DisplayName("updateBidItem: happy path delegates to repo with enforced path id")
        void updateBidItem_ok() {
            BidItems input = new BidItems();
            input.setItemQuantity(2);
            input.setItemPrice(new BigDecimal("9.99"));

            when(repo.updateBidItem(any(BidItems.class))).thenReturn(true);

            service.updateBidItem(123, input);

            ArgumentCaptor<BidItems> captor = ArgumentCaptor.forClass(BidItems.class);
            verify(repo).updateBidItem(captor.capture());

            BidItems passed = captor.getValue();
            assertEquals(123, passed.getBidItemId());
            assertEquals(2, passed.getItemQuantity());
            assertEquals(new BigDecimal("9.99"), passed.getItemPrice());
        }

        @Test
        @DisplayName("updateBidItem: null item rejected")
        void updateBidItem_null() {
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidItem(5, null));
            assertTrue(ex.getMessage().contains("BidItems cannot be null"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("updateBidItem: quantity must be > 0")
        void updateBidItem_badQuantity() {
            BidItems input = new BidItems();
            input.setItemQuantity(0);
            input.setItemPrice(new BigDecimal("1.00"));

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidItem(5, input));
            assertTrue(ex.getMessage().contains("itemQuantity must be > 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("updateBidItem: price must be >= 0")
        void updateBidItem_badPrice() {
            BidItems input = new BidItems();
            input.setItemQuantity(1);
            input.setItemPrice(new BigDecimal("-0.01"));

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> service.updateBidItem(5, input));
            assertTrue(ex.getMessage().contains("itemPrice must be >= 0"));
            verifyNoInteractions(repo);
        }

        @Test
        @DisplayName("updateBidItem: not found -> ResourceNotFoundException")
        void updateBidItem_notFound() {
            BidItems input = new BidItems();
            input.setItemQuantity(1);
            input.setItemPrice(new BigDecimal("0.00"));

            when(repo.updateBidItem(any(BidItems.class))).thenReturn(false);

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.updateBidItem(999, input));
            assertTrue(ex.getMessage().contains("BidItem 999 not found"));

            verify(repo).updateBidItem(any(BidItems.class));
        }
    }

    // ==========================================================
    // DELETE
    // ==========================================================
    @Nested
    class DeleteTests {

        @Test
        @DisplayName("deleteBid: happy path")
        void deleteBid_ok() {
            when(repo.deleteById(1)).thenReturn(true);
            assertDoesNotThrow(() -> service.deleteBid(1));
            verify(repo).deleteById(1);
        }

        @Test
        @DisplayName("deleteBid: not found")
        void deleteBid_notFound() {
            when(repo.deleteById(404)).thenReturn(false);

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.deleteBid(404));
            assertTrue(ex.getMessage().contains("Bid 404 not found"));

            verify(repo).deleteById(404);
        }

        @Test
        @DisplayName("deleteBidItem: happy path")
        void deleteBidItem_ok() {
            when(repo.deleteBidItem(11)).thenReturn(true);
            assertDoesNotThrow(() -> service.deleteBidItem(11));
            verify(repo).deleteBidItem(11);
        }

        @Test
        @DisplayName("deleteBidItem: not found")
        void deleteBidItem_notFound() {
            when(repo.deleteBidItem(12)).thenReturn(false);

            ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class,
                    () -> service.deleteBidItem(12));
            assertTrue(ex.getMessage().contains("BidItem 12 not found"));

            verify(repo).deleteBidItem(12);
        }
    }
}
