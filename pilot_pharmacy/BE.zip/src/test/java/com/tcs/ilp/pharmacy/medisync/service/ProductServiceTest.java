package com.tcs.ilp.pharmacy.medisync.service;


import com.tcs.ilp.pharmacy.medisync.exception.InvalidBatchReferenceException;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.entity.Batch;
import com.tcs.ilp.pharmacy.medisync.entity.Product;
import com.tcs.ilp.pharmacy.medisync.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository repo;

    @InjectMocks
    private ProductService service;

    private Product validProduct;

    @BeforeEach
    void setup() {
        validProduct = buildValidProduct();
    }

    // ---------- CREATE ----------

    @Test
    void create_shouldInsertAndReturnCreatedProduct() {
        int generatedId = 10;

        when(repo.insert(any(Product.class))).thenReturn(generatedId);

        Product fromDb = buildValidProduct();
        fromDb.setProductId(generatedId);
        when(repo.findById(generatedId)).thenReturn(Optional.of(fromDb));

        Product result = service.create(validProduct);

        assertNotNull(result);
        assertEquals(generatedId, result.getProductId());
        assertEquals("Paracetamol", result.getProductName());

        ArgumentCaptor<Product> captor = ArgumentCaptor.forClass(Product.class);
        verify(repo).insert(captor.capture());
        assertNull(captor.getValue().getProductId()); // service nulls ID before insert

        verify(repo).findById(generatedId);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void create_shouldThrowRuntimeException_whenInsertReturnsInvalidId() {
        when(repo.insert(any(Product.class))).thenReturn(0);

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> service.create(validProduct));

        assertTrue(ex.getMessage().contains("Failed to create product"));
        verify(repo).insert(any(Product.class));
        verifyNoMoreInteractions(repo);
    }

    @Test
    void create_shouldThrowInvalidBatchReferenceException_onFkViolation23503() {
        SQLException sqlEx = new SQLException("FK violation", "23503");
        DataIntegrityViolationException dive = new DataIntegrityViolationException("constraint", sqlEx);

        when(repo.insert(any(Product.class))).thenThrow(dive);

        InvalidBatchReferenceException ex = assertThrows(
                InvalidBatchReferenceException.class,
                () -> service.create(validProduct)
        );

        assertTrue(ex.getMessage().contains("Invalid batchId"));
        verify(repo).insert(any(Product.class));
        verifyNoMoreInteractions(repo);
    }

    // ---------- READ ONE ----------

    @Test
    void getById_shouldReturnProduct_whenFound() {
        when(repo.findById(1)).thenReturn(Optional.of(validProduct));

        Product result = service.getById(1);

        assertNotNull(result);
        verify(repo).findById(1);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void getById_shouldThrowNotFound_whenMissing() {
        when(repo.findById(99)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class,
                () -> service.getById(99));

        assertTrue(ex.getMessage().contains("Product not found"));
        verify(repo).findById(99);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void getById_shouldThrowIllegalArgument_whenIdInvalid() {
        assertThrows(IllegalArgumentException.class, () -> service.getById(0));
        assertThrows(IllegalArgumentException.class, () -> service.getById(-5));
        verifyNoInteractions(repo);
    }

    // ---------- READ ALL ----------

    @Test
    void getAll_shouldReturnList() {
        when(repo.findAll()).thenReturn(List.of(validProduct));

        List<Product> list = service.getAll();

        assertEquals(1, list.size());
        verify(repo).findAll();
        verifyNoMoreInteractions(repo);
    }

    // ---------- UPDATE ----------

    @Test
    void update_shouldUpdateAndReturnUpdatedProduct() {
        int id = 5;

        Product existing = buildValidProduct();
        existing.setProductId(id);

        Product updatedFromDb = buildValidProduct();
        updatedFromDb.setProductId(id);
        updatedFromDb.setProductName("UpdatedName");

        // getById called twice: before update and after update
        when(repo.findById(id)).thenReturn(Optional.of(existing), Optional.of(updatedFromDb));

        when(repo.update(any(Product.class))).thenReturn(true);

        Product input = buildValidProduct();
        input.setProductName("UpdatedName");

        Product result = service.update(id, input);

        assertEquals(id, result.getProductId());
        assertEquals("UpdatedName", result.getProductName());

        ArgumentCaptor<Product> captor = ArgumentCaptor.forClass(Product.class);
        verify(repo).update(captor.capture());
        assertEquals(id, captor.getValue().getProductId());

        verify(repo, times(2)).findById(id);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void update_shouldThrowInvalidBatchReferenceException_onFkViolation23503() {
        int id = 7;

        Product existing = buildValidProduct();
        existing.setProductId(id);

        when(repo.findById(id)).thenReturn(Optional.of(existing));

        SQLException sqlEx = new SQLException("FK violation", "23503");
        DataIntegrityViolationException dive = new DataIntegrityViolationException("constraint", sqlEx);

        when(repo.update(any(Product.class))).thenThrow(dive);

        InvalidBatchReferenceException ex = assertThrows(
                InvalidBatchReferenceException.class,
                () -> service.update(id, validProduct)
        );

        assertTrue(ex.getMessage().contains("Invalid batchId"));
        verify(repo).findById(id);
        verify(repo).update(any(Product.class));
        verifyNoMoreInteractions(repo);
    }

    @Test
    void update_shouldThrowNotFound_whenUpdateReturnsFalse() {
        int id = 3;

        Product existing = buildValidProduct();
        existing.setProductId(id);

        when(repo.findById(id)).thenReturn(Optional.of(existing));
        when(repo.update(any(Product.class))).thenReturn(false);

        NotFoundException ex = assertThrows(NotFoundException.class,
                () -> service.update(id, validProduct));

        assertTrue(ex.getMessage().contains("Product not found"));
        verify(repo).findById(id);
        verify(repo).update(any(Product.class));
        verifyNoMoreInteractions(repo);
    }

    // ---------- DELETE ----------

    @Test
    void delete_shouldSucceed_whenRepoReturnsTrue() {
        when(repo.delete(8)).thenReturn(true);

        assertDoesNotThrow(() -> service.delete(8));

        verify(repo).delete(8);
        verifyNoMoreInteractions(repo);
    }

    @Test
    void delete_shouldThrowNotFound_whenRepoReturnsFalse() {
        when(repo.delete(9)).thenReturn(false);

        NotFoundException ex = assertThrows(NotFoundException.class,
                () -> service.delete(9));

        assertTrue(ex.getMessage().contains("Product not found"));
        verify(repo).delete(9);
        verifyNoMoreInteractions(repo);
    }

    // ---------- VALIDATION ----------

    @Test
    void create_shouldFailValidation_whenNameEmpty() {
        Product bad = buildValidProduct();
        bad.setProductName("   ");

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.create(bad));

        assertTrue(ex.getMessage().contains("Product name cannot be empty"));
        verifyNoInteractions(repo);
    }

    // ---------- helper ----------

    private Product buildValidProduct() {
        Batch b = new Batch();
        b.setBatchId(1);

        Product p = new Product();
        p.setProductId(100); // create() should null this before insert
        p.setProductName("Paracetamol");
        p.setCategory("Tablet");
        p.setQuantityTotal(50);
        p.setPrice(10.0);
        p.setExpiryDate(LocalDate.now().plusMonths(6));
        p.setBatch(b);
        return p;
    }
}
