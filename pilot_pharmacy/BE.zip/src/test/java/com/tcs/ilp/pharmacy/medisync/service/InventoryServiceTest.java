
package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.exception.ConflictException;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import com.tcs.ilp.pharmacy.medisync.repository.InventoryRepository;
import com.tcs.ilp.pharmacy.medisync.service.InventoryService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventoryServiceTest {

    @Mock
    private InventoryRepository repo;

    @InjectMocks
    private InventoryService service;

    // -------------------- CREATE --------------------

    @Test
    @DisplayName("createInventory: saves inventory when valid and not duplicate")
    void createInventory_success() {
        int batchId = 101;
        int storeId = 1;

        when(repo.existsByBatchIdAndStoreId(batchId, storeId)).thenReturn(false);

        Inventory saved = new Inventory(batchId, storeId);
        saved.setInventoryId(10);
        when(repo.save(any(Inventory.class))).thenReturn(saved);

        Inventory result = service.createInventory(batchId, storeId);

        assertNotNull(result);
        assertEquals(10, result.getInventoryId());
        assertEquals(batchId, result.getBatchId());
        assertEquals(storeId, result.getStoreId());

        ArgumentCaptor<Inventory> captor = ArgumentCaptor.forClass(Inventory.class);
        verify(repo).existsByBatchIdAndStoreId(batchId, storeId);
        verify(repo).save(captor.capture());
        assertEquals(batchId, captor.getValue().getBatchId());
        assertEquals(storeId, captor.getValue().getStoreId());

        verifyNoMoreInteractions(repo);
    }

    @Test
    @DisplayName("createInventory: throws IllegalArgumentException when batchId/storeId is null")
    void createInventory_nulls() {
        assertThrows(IllegalArgumentException.class, () -> service.createInventory(null, 1));
        assertThrows(IllegalArgumentException.class, () -> service.createInventory(1, null));
        verifyNoInteractions(repo);
    }

    @Test
    @DisplayName("createInventory: throws ConflictException when duplicate exists")
    void createInventory_conflict() {
        when(repo.existsByBatchIdAndStoreId(101, 1)).thenReturn(true);

        assertThrows(ConflictException.class, () -> service.createInventory(101, 1));

        verify(repo).existsByBatchIdAndStoreId(101, 1);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- READ --------------------

    @Test
    @DisplayName("getInventoryById: returns inventory when found")
    void getInventoryById_found() {
        Inventory inv = new Inventory(10, 20);
        inv.setInventoryId(5);

        when(repo.findById(5)).thenReturn(Optional.of(inv));

        Inventory result = service.getInventoryById(5);

        assertEquals(5, result.getInventoryId());
        verify(repo).findById(5);
        verifyNoMoreInteractions(repo);
    }

    @Test
    @DisplayName("getInventoryById: throws NotFoundException when missing")
    void getInventoryById_notFound() {
        when(repo.findById(999)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.getInventoryById(999));

        verify(repo).findById(999);
        verifyNoMoreInteractions(repo);
    }

    @Test
    @DisplayName("getAllInventories: no filters => findAll()")
    void getAllInventories_noFilters() {
        when(repo.findAll()).thenReturn(List.of(new Inventory(1, 1)));

        List<Inventory> result = service.getAllInventories(Optional.empty(), Optional.empty());

        assertEquals(1, result.size());
        verify(repo).findAll();
        verifyNoMoreInteractions(repo);
    }

    @Test
    @DisplayName("getAllInventories: store filter => findByStoreId()")
    void getAllInventories_storeFilter() {
        when(repo.findByStoreId(2)).thenReturn(List.of(new Inventory(10, 2)));

        List<Inventory> result = service.getAllInventories(Optional.of(2), Optional.empty());

        assertEquals(1, result.size());
        assertEquals(2, result.get(0).getStoreId());
        verify(repo).findByStoreId(2);
        verifyNoMoreInteractions(repo);
    }

    @Test
    @DisplayName("getAllInventories: batch filter => findByBatchId()")
    void getAllInventories_batchFilter() {
        when(repo.findByBatchId(7)).thenReturn(List.of(new Inventory(7, 99)));

        List<Inventory> result = service.getAllInventories(Optional.empty(), Optional.of(7));

        assertEquals(1, result.size());
        assertEquals(7, result.get(0).getBatchId());
        verify(repo).findByBatchId(7);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- PUT (replace) --------------------

    @Test
    @DisplayName("replaceInventory: throws IllegalArgumentException if batchId/storeId missing")
    void replaceInventory_requiresBothFields() {
        assertThrows(IllegalArgumentException.class, () -> service.replaceInventory(1, null, 2));
        assertThrows(IllegalArgumentException.class, () -> service.replaceInventory(1, 2, null));
        verifyNoInteractions(repo);
    }

    @Test
    @DisplayName("replaceInventory: updates and saves when valid and not conflicting")
    void replaceInventory_success() {
        Inventory existing = new Inventory(1, 1);
        existing.setInventoryId(50);

        when(repo.findById(50)).thenReturn(Optional.of(existing));
        when(repo.existsByBatchIdAndStoreId(2, 3)).thenReturn(false);
        when(repo.save(existing)).thenReturn(existing);

        Inventory result = service.replaceInventory(50, 2, 3);

        assertEquals(2, result.getBatchId());
        assertEquals(3, result.getStoreId());

        verify(repo).findById(50);
        verify(repo).existsByBatchIdAndStoreId(2, 3);
        verify(repo).save(existing);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- PATCH --------------------

    @Test
    @DisplayName("patchInventory: updates only provided field and saves")
    void patchInventory_partialUpdate() {
        Inventory existing = new Inventory(10, 20);
        existing.setInventoryId(60);

        when(repo.findById(60)).thenReturn(Optional.of(existing));
        when(repo.existsByBatchIdAndStoreId(10, 99)).thenReturn(false);
        when(repo.save(existing)).thenReturn(existing);

        Inventory result = service.patchInventory(60, null, 99);

        assertEquals(10, result.getBatchId());  // unchanged
        assertEquals(99, result.getStoreId());  // updated

        verify(repo).findById(60);
        verify(repo).existsByBatchIdAndStoreId(10, 99);
        verify(repo).save(existing);
        verifyNoMoreInteractions(repo);
    }

    // -------------------- DELETE --------------------

    @Test
    @DisplayName("deleteInventory: deletes when exists")
    void deleteInventory_success() {
        Inventory existing = new Inventory(1, 1);
        existing.setInventoryId(70);

        when(repo.findById(70)).thenReturn(Optional.of(existing));

        service.deleteInventory(70);

        verify(repo).findById(70);
        verify(repo).delete(existing);
        verifyNoMoreInteractions(repo);
    }
}
