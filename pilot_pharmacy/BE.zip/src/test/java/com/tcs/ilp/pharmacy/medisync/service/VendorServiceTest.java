package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.*;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.entity.Vendor;
import com.tcs.ilp.pharmacy.medisync.entity.VendorDocuments;
import com.tcs.ilp.pharmacy.medisync.repository.UsersRepository;
import com.tcs.ilp.pharmacy.medisync.repository.VendorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VendorServiceTest {

    @Mock private VendorRepository vendorRepository;
    @Mock private UsersRepository usersRepository;

    private VendorService vendorService;

    @BeforeEach
    void setup() {
        vendorService = new VendorService(vendorRepository, usersRepository, 2);
    }

    private VendorRegisterRequest validRegisterRequest() {
        VendorRegisterRequest req = new VendorRegisterRequest();
        req.setBusinessName("ABC Pharma");
        req.setEmail("abc@pharma.com");
        req.setPhoneNumber("9999999999");
        req.setPassword("plainPass");
        req.setGstNumber("GST123");
        req.setLicenseNumber("LIC123");
        req.setAddress("Trivandrum");
        return req;
    }

    // ================== registerVendor ==================

    @Test
    void registerVendor_positive_shouldCreateUserAndVendor() {
        VendorRegisterRequest req = validRegisterRequest();

        when(vendorRepository.existsByGstNumber(req.getGstNumber())).thenReturn(false);
        when(vendorRepository.existsByLicenseNumber(req.getLicenseNumber())).thenReturn(false);

        when(usersRepository.addUser(any(Users.class))).thenReturn(10);

        Vendor savedVendor = new Vendor();
        savedVendor.setVendorId(20);
        savedVendor.setStatus("PENDING");
        savedVendor.setGstNumber("GST123");
        savedVendor.setLicenseNumber("LIC123");
        savedVendor.setAddress("Trivandrum");

        when(vendorRepository.save(any(Vendor.class))).thenReturn(savedVendor);

        VendorResponse res = vendorService.registerVendor(req);

        assertNotNull(res);
        assertEquals(20, res.getVendorId());
        assertEquals("PENDING", res.getStatus());

        ArgumentCaptor<Users> uCap = ArgumentCaptor.forClass(Users.class);
        verify(usersRepository).addUser(uCap.capture());
        assertEquals("plainPass", uCap.getValue().getPassword());

        verify(vendorRepository).save(any(Vendor.class));
    }

    @Test
    void registerVendor_neutral_phoneNull_shouldSucceed() {
        VendorRegisterRequest req = validRegisterRequest();
        req.setPhoneNumber(null);

        when(vendorRepository.existsByGstNumber(req.getGstNumber())).thenReturn(false);
        when(vendorRepository.existsByLicenseNumber(req.getLicenseNumber())).thenReturn(false);
        when(usersRepository.addUser(any(Users.class))).thenReturn(10);

        Vendor savedVendor = new Vendor();
        savedVendor.setVendorId(20);
        savedVendor.setStatus("PENDING");
        when(vendorRepository.save(any(Vendor.class))).thenReturn(savedVendor);

        assertNotNull(vendorService.registerVendor(req));
    }

    @Test
    void registerVendor_negative_nullRequest_should400() {
        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.registerVendor(null));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
        verifyNoInteractions(usersRepository, vendorRepository);
    }

    @Test
    void registerVendor_negative_missingFields_should400() {
        VendorRegisterRequest req = new VendorRegisterRequest();
        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.registerVendor(req));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
        verifyNoInteractions(usersRepository, vendorRepository);
    }

    @Test
    void registerVendor_negative_gstExists_should409() {
        VendorRegisterRequest req = validRegisterRequest();
        when(vendorRepository.existsByGstNumber(req.getGstNumber())).thenReturn(true);

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.registerVendor(req));
        assertEquals(HttpStatus.CONFLICT, ex.getStatusCode());

        verifyNoInteractions(usersRepository);
        verify(vendorRepository, never()).save(any());
    }

    @Test
    void registerVendor_negative_licenseExists_should409() {
        VendorRegisterRequest req = validRegisterRequest();
        when(vendorRepository.existsByGstNumber(req.getGstNumber())).thenReturn(false);
        when(vendorRepository.existsByLicenseNumber(req.getLicenseNumber())).thenReturn(true);

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.registerVendor(req));
        assertEquals(HttpStatus.CONFLICT, ex.getStatusCode());
    }

    @Test
    void registerVendor_negative_emailDuplicate_should409() {
        VendorRegisterRequest req = validRegisterRequest();

        when(vendorRepository.existsByGstNumber(req.getGstNumber())).thenReturn(false);
        when(vendorRepository.existsByLicenseNumber(req.getLicenseNumber())).thenReturn(false);

        when(usersRepository.addUser(any(Users.class)))
                .thenThrow(new DataIntegrityViolationException("duplicate key"));

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.registerVendor(req));

        assertEquals(HttpStatus.CONFLICT, ex.getStatusCode());
        verify(vendorRepository, never()).save(any());
    }

    // ================== uploadDocument ==================

    @Test
    void uploadDocument_positive_shouldAddDocAndSaveVendor() {
        int vendorId = 50;

        Vendor vendor = new Vendor();
        vendor.setVendorId(vendorId);
        vendor.setDocuments(new ArrayList<>());

        when(vendorRepository.findById(vendorId)).thenReturn(Optional.of(vendor));
        when(vendorRepository.save(any(Vendor.class))).thenAnswer(inv -> inv.getArgument(0));

        VendorDocumentUploadRequest req = new VendorDocumentUploadRequest();
        req.setDocType("DRUG");
        req.setFileUrl("http://x/doc.pdf");

        VendorDocumentResponse res = vendorService.uploadDocument(vendorId, req);

        assertNotNull(res);
        assertEquals(vendorId, res.getVendorId());
        assertEquals(1, vendor.getDocuments().size());

        VendorDocuments doc = vendor.getDocuments().get(0);
        assertEquals("DRUG", doc.getDocType());

        verify(vendorRepository).save(vendor);

        // ✅ Removed flush verification because JDBC repo/service no longer uses flush()
        // verify(vendorRepository).flush();
    }

    @Test
    void uploadDocument_neutral_docTypeLowercase_shouldSucceed() {
        int vendorId = 51;

        Vendor vendor = new Vendor();
        vendor.setVendorId(vendorId);
        vendor.setDocuments(new ArrayList<>());

        when(vendorRepository.findById(vendorId)).thenReturn(Optional.of(vendor));
        when(vendorRepository.save(any(Vendor.class))).thenAnswer(inv -> inv.getArgument(0));

        VendorDocumentUploadRequest req = new VendorDocumentUploadRequest();
        req.setDocType("drug");
        req.setFileUrl("http://x/doc.png");

        assertNotNull(vendorService.uploadDocument(vendorId, req));
    }

    @Test
    void uploadDocument_negative_nullVendorId_should400() {
        VendorDocumentUploadRequest req = new VendorDocumentUploadRequest();
        req.setDocType("DRUG");
        req.setFileUrl("x.pdf");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.uploadDocument(null, req));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
    }

    @Test
    void uploadDocument_negative_blankFields_should400() {
        VendorDocumentUploadRequest req = new VendorDocumentUploadRequest();
        req.setDocType(" ");
        req.setFileUrl("");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.uploadDocument(1, req));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatusCode());
    }

    @Test
    void uploadDocument_negative_vendorNotFound_should404() {
        when(vendorRepository.findById(99)).thenReturn(Optional.empty());

        VendorDocumentUploadRequest req = new VendorDocumentUploadRequest();
        req.setDocType("DRUG");
        req.setFileUrl("x.pdf");

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> vendorService.uploadDocument(99, req));
        assertEquals(HttpStatus.NOT_FOUND, ex.getStatusCode());
    }
}