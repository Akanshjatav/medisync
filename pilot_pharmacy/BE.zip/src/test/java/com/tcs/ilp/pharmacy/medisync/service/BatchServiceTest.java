package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.entity.Batch;
import com.tcs.ilp.pharmacy.medisync.repository.BatchRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for BatchService service using Mockito to mock BatchDao.
 *
 * This test suite targets ONLY service-layer behavior:
 *  - Validations enforced by BatchService
 *  - Correct delegation to BatchDao
 *  - Proper handling of DAO outcomes (success/failure/empty)
 */
@ExtendWith(MockitoExtension.class)
class BatchServiceTest {

    @Mock
    private BatchRepository dao;

    @InjectMocks
    private BatchService service;

    private Batch mkBatch(Integer id, Integer batchNumber, LocalDate date, Integer vendorId) {
        Batch b = new Batch();
        // Adjust setter names if your Batch model differs
        b.setBatchId(id);
        b.setBatchNumber(batchNumber);
        b.setDeliveryDate(date);
        b.setVendorId(vendorId);
        return b;
    }

    private Batch validNew() {
        return mkBatch(null, 1001, LocalDate.of(2026, 1, 15), 10);
    }

    private Batch validExisting() {
        return mkBatch(1, 1001, LocalDate.of(2026, 1, 15), 10);
    }

    // ---------------- addBatch ----------------

    @Test
    void addBatch_happyPath_returnsCreatedWithId() {
        Batch input = validNew();
        Batch created = mkBatch(1, input.getBatchNumber(), input.getDeliveryDate(), input.getVendorId());
        when(dao.addBatch(input)).thenReturn(created);

        Batch result = service.addBatch(input);

        assertNotNull(result);
        assertEquals(1, result.getBatchId());
        assertEquals(input.getBatchNumber(), result.getBatchNumber());
        assertEquals(input.getDeliveryDate(), result.getDeliveryDate());
        assertEquals(input.getVendorId(), result.getVendorId());
        verify(dao, times(1)).addBatch(input);
        verifyNoMoreInteractions(dao);
    }

    @Test
    void addBatch_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.addBatch(null));
        verifyNoInteractions(dao);
    }

    @Test
    void addBatch_invalidFields_throws_noDaoCall() {
        // batchNumber <= 0
        Batch b1 = mkBatch(null, 0, LocalDate.now(), 10);
        assertThrows(IllegalArgumentException.class, () -> service.addBatch(b1));

        // deliveryDate null
        Batch b2 = mkBatch(null, 1, null, 10);
        assertThrows(IllegalArgumentException.class, () -> service.addBatch(b2));

        // vendorId <= 0
        Batch b3 = mkBatch(null, 1, LocalDate.now(), 0);
        assertThrows(IllegalArgumentException.class, () -> service.addBatch(b3));

        verifyNoInteractions(dao);
    }

    @Test
    void addBatch_daoReturnsNullOrInvalidId_throws() {
        Batch input = validNew();

        when(dao.addBatch(input))
                .thenReturn(null)                             // 1st call -> null
                .thenReturn(mkBatch(null, 1, LocalDate.now(), 1)) // 2nd call -> id null
                .thenReturn(mkBatch(0, 1, LocalDate.now(), 1));   // 3rd call -> id <= 0

        assertThrows(RuntimeException.class, () -> service.addBatch(input));
        assertThrows(RuntimeException.class, () -> service.addBatch(input));
        assertThrows(RuntimeException.class, () -> service.addBatch(input));

        verify(dao, times(3)).addBatch(input);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- getBatch ----------------

    @Test
    void getBatch_invalidId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.getBatch(0));
        assertThrows(IllegalArgumentException.class, () -> service.getBatch(-1));
        verifyNoInteractions(dao);
    }

    @Test
    void getBatch_found_returnsOptional() {
        Batch existing = validExisting();
        when(dao.getBatchById(1)).thenReturn(Optional.of(existing));

        Optional<Batch> result = service.getBatch(1);

        assertTrue(result.isPresent());
        assertEquals(existing, result.get());
        verify(dao).getBatchById(1);
        verifyNoMoreInteractions(dao);
    }

    @Test
    void getBatch_notFound_returnsEmpty() {
        when(dao.getBatchById(99)).thenReturn(Optional.empty());

        Optional<Batch> result = service.getBatch(99);

        assertTrue(result.isEmpty());
        verify(dao).getBatchById(99);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- listAllBatches ----------------

    @Test
    void listAllBatches_returnsList() {
        when(dao.getAllBatches()).thenReturn(List.of(validExisting()));

        List<Batch> list = service.listAllBatches();

        assertEquals(1, list.size());
        verify(dao).getAllBatches();
        verifyNoMoreInteractions(dao);
    }

    // ---------------- getByVendor ----------------

    @Test
    void getByVendor_invalidId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.getByVendor(0));
        assertThrows(IllegalArgumentException.class, () -> service.getByVendor(-5));
        verifyNoInteractions(dao);
    }

    @Test
    void getByVendor_ok() {
        when(dao.getBatchesByVendor(10)).thenReturn(List.of(validExisting()));

        List<Batch> list = service.getByVendor(10);

        assertEquals(1, list.size());
        verify(dao).getBatchesByVendor(10);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- getDeliveredBetween ----------------

    @Test
    void getDeliveredBetween_nullDates_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.getDeliveredBetween(null, LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> service.getDeliveredBetween(LocalDate.now(), null));
        verifyNoInteractions(dao);
    }

    @Test
    void getDeliveredBetween_toBeforeFrom_throws() {
        LocalDate from = LocalDate.of(2026, 1, 10);
        LocalDate to = LocalDate.of(2026, 1, 1);
        assertThrows(IllegalArgumentException.class, () -> service.getDeliveredBetween(from, to));
        verifyNoInteractions(dao);
    }

    @Test
    void getDeliveredBetween_ok() {
        LocalDate from = LocalDate.of(2026, 1, 1);
        LocalDate to = LocalDate.of(2026, 1, 31);
        when(dao.getBatchesDeliveredBetween(from, to)).thenReturn(List.of(validExisting()));

        List<Batch> list = service.getDeliveredBetween(from, to);

        assertEquals(1, list.size());
        verify(dao).getBatchesDeliveredBetween(from, to);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- getPage ----------------

    @Test
    void getPage_invalidParams_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.getPage(0, 10));
        assertThrows(IllegalArgumentException.class, () -> service.getPage(1, 0));
        assertThrows(IllegalArgumentException.class, () -> service.getPage(-1, 5));
        verifyNoInteractions(dao);
    }

    @Test
    void getPage_delegatesWithSamePageAndSize() {
        when(dao.getPage(1, 10)).thenReturn(List.of(validExisting()));

        List<Batch> list = service.getPage(1, 10);

        assertEquals(1, list.size());
        verify(dao).getPage(1, 10);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- getSortedByDeliveryDate ----------------

    @Test
    void getSortedByDeliveryDate_true() {
        when(dao.getSortedByDeliveryDate(true)).thenReturn(List.of(validExisting()));

        List<Batch> list = service.getSortedByDeliveryDate(true);

        assertEquals(1, list.size());
        verify(dao).getSortedByDeliveryDate(true);
        verifyNoMoreInteractions(dao);
    }

    @Test
    void getSortedByDeliveryDate_false() {
        when(dao.getSortedByDeliveryDate(false)).thenReturn(List.of());

        List<Batch> list = service.getSortedByDeliveryDate(false);

        assertTrue(list.isEmpty());
        verify(dao).getSortedByDeliveryDate(false);
        verifyNoMoreInteractions(dao);
    }

    // ---------------- updateBatch ----------------

    @Test
    void updateBatch_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.updateBatch(null));
        verifyNoInteractions(dao);
    }

    @Test
    void updateBatch_missingId_throws() {
        Batch b = validNew(); // id is null
        assertThrows(IllegalArgumentException.class, () -> service.updateBatch(b));
        verifyNoInteractions(dao);
    }

    @Test
    void updateBatch_invalidFields_throws() {
        Batch b = validExisting();
        b.setBatchNumber(0); // invalid
        assertThrows(IllegalArgumentException.class, () -> service.updateBatch(b));
        verifyNoInteractions(dao);
    }

    @Test
    void updateBatch_daoReturnsFalse_throws() {
        Batch b = validExisting();
        when(dao.updateBatch(b)).thenReturn(false);

        assertThrows(RuntimeException.class, () -> service.updateBatch(b));

        verify(dao).updateBatch(b);
        verify(dao, never()).getBatchById(anyInt());
        verifyNoMoreInteractions(dao);
    }

    @Test
    void updateBatch_ok_reloadMissing_throws() {
        Batch b = validExisting();
        when(dao.updateBatch(b)).thenReturn(true);
        when(dao.getBatchById(b.getBatchId())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> service.updateBatch(b));

        verify(dao).updateBatch(b);
        verify(dao).getBatchById(b.getBatchId());
        verifyNoMoreInteractions(dao);
    }

    @Test
    void updateBatch_ok_returnsReloadedEntity() {
        Batch b = validExisting();
        when(dao.updateBatch(b)).thenReturn(true);
        when(dao.getBatchById(b.getBatchId())).thenReturn(Optional.of(b));

        Batch result = service.updateBatch(b);

        assertEquals(b, result);
        verify(dao).updateBatch(b);
        verify(dao).getBatchById(b.getBatchId());
        verifyNoMoreInteractions(dao);
    }

    // ---------------- removeBatch ----------------

    @Test
    void removeBatch_invalidId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.removeBatch(0));
        assertThrows(IllegalArgumentException.class, () -> service.removeBatch(-10));
        verifyNoInteractions(dao);
    }

    @Test
    void removeBatch_delegatesToDao() {
        when(dao.deleteBatch(1)).thenReturn(true);
        when(dao.deleteBatch(2)).thenReturn(false);

        assertTrue(service.removeBatch(1));
        assertFalse(service.removeBatch(2));

        verify(dao).deleteBatch(1);
        verify(dao).deleteBatch(2);
        verifyNoMoreInteractions(dao);
    }
}