package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.RfqDto;
import com.tcs.ilp.pharmacy.medisync.dto.RfqItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.RfqPayloadDto;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.RfqItems;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.RfqService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/rfqs")
@CrossOrigin
public class RfqController {

    private final RfqService service;

    public RfqController(RfqService service) {
        this.service = service;
    }

    // -------------------- GET: list all RFQs --------------------
    @GetMapping
    public ResponseEntity<List<RfqDto>> listAll() {
        List<RfqDto> out = service.listAll().stream()
                .map(this::toRfqDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(out);
    }

    // -------------------- GET: RFQ + items by id --------------------
    @GetMapping("/{id}")
    public ResponseEntity<RfqPayloadDto> getById(@PathVariable("id") Integer id) {
        requirePositive(id, "RFQ id must be a positive number");

        Rfq rfq = service.getRfq(id);                // should throw NotFoundException if missing
        List<RfqItems> items = service.getItems(id); // empty list ok

        return ResponseEntity.ok(new RfqPayloadDto(
                toRfqDto(rfq),
                items.stream().map(this::toItemDto).collect(Collectors.toList())
        ));
    }

    // -------------------- POST: create RFQ + items --------------------
    @PostMapping
    public ResponseEntity<RfqPayloadDto> create(@RequestBody RfqPayloadDto payload) {
        requireBody(payload, "Request body is required");
        if (payload.getRfq() == null) throw new ValidationException("Request must contain 'rfq'");
        if (payload.getItems() == null) throw new ValidationException("Request must contain 'items'");
        if (payload.getItems().isEmpty()) throw new ValidationException("items cannot be empty");

        validateRfqDtoForCreate(payload.getRfq());
        validateItemDtos(payload.getItems(), true);

        Rfq rfqEntity = toRfqEntity(payload.getRfq());
        List<RfqItems> itemEntities = toItemEntities(payload.getItems(), null); // rfqId assigned after create

        int newId = service.createWithItems(rfqEntity, itemEntities);

        Rfq created = service.getRfq(newId);
        List<RfqItems> createdItems = service.getItems(newId);

        RfqPayloadDto response = new RfqPayloadDto(
                toRfqDto(created),
                createdItems.stream().map(this::toItemDto).collect(Collectors.toList())
        );

        return ResponseEntity
                .created(URI.create("/api/v1/rfqs/" + newId))
                .body(response);
    }

    // -------------------- PUT: update RFQ + replace items --------------------
    @PutMapping("/{id}")
    public ResponseEntity<RfqPayloadDto> update(@PathVariable("id") Integer id,
                                                @RequestBody RfqPayloadDto payload) {
        requirePositive(id, "RFQ id must be a positive number");
        requireBody(payload, "Request body is required");
        if (payload.getRfq() == null) throw new ValidationException("Request must contain 'rfq'");
        if (payload.getItems() == null) throw new ValidationException("Request must contain 'items' (can be empty to clear)");

        // Path id wins
        payload.getRfq().setRfqId(id);

        validateRfqDtoForUpdate(payload.getRfq());
        validateItemDtos(payload.getItems(), false); // allow empty to clear

        Rfq rfqEntity = toRfqEntity(payload.getRfq());
        List<RfqItems> itemEntities = toItemEntities(payload.getItems(), id);

        service.updateWithItems(rfqEntity, itemEntities);

        Rfq updated = service.getRfq(id);
        List<RfqItems> updatedItems = service.getItems(id);

        return ResponseEntity.ok(new RfqPayloadDto(
                toRfqDto(updated),
                updatedItems.stream().map(this::toItemDto).collect(Collectors.toList())
        ));
    }

    // -------------------- DELETE: delete RFQ + items --------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Integer id) {
        requirePositive(id, "RFQ id must be a positive number");
        service.deleteCascade(id); // should throw NotFoundException if missing
        return ResponseEntity.noContent().build();
    }

    // -------------------- OPTIONAL: filter by createdBy --------------------
    @GetMapping("/createdBy/{createdBy}")
    public ResponseEntity<List<RfqDto>> listByCreatedBy(@PathVariable("createdBy") Integer createdBy) {
        requirePositive(createdBy, "createdBy must be a positive number");

        List<RfqDto> out = service.listByCreatedBy(createdBy).stream()
                .map(this::toRfqDto)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // -------------------- OPTIONAL: award/update statusAward --------------------
    @PutMapping("/{id}/award")
    public ResponseEntity<RfqDto> award(@PathVariable("id") Integer id,
                                        @RequestParam("status") String status) {
        requirePositive(id, "RFQ id must be a positive number");
        if (status == null || status.trim().isEmpty()) {
            throw new ValidationException("status query param is required");
        }

        service.award(id, status.trim());

        Rfq rfq = service.getRfq(id);
        return ResponseEntity.ok(toRfqDto(rfq));
    }

    // ============================================================
    // Validation helpers
    // ============================================================

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requirePositive(Integer value, String message) {
        if (value == null || value <= 0) throw new ValidationException(message);
    }

    private void validateRfqDtoForCreate(RfqDto rfq) {
        if (rfq.getCreatedBy() == null || rfq.getCreatedBy() <= 0) {
            throw new ValidationException("rfq.createdBy must be a positive number");
        }
        if (rfq.getStatusAward() == null || rfq.getStatusAward().trim().isEmpty()) {
            throw new ValidationException("rfq.statusAward is required");
        }
        // optional: validate deadlines if your business wants it
        // e.g. submissionDeadline != null, expectedDeliveryDate != null
    }

    private void validateRfqDtoForUpdate(RfqDto rfq) {
        if (rfq.getRfqId() == null || rfq.getRfqId() <= 0) {
            throw new ValidationException("rfq.rfqId must be a positive number");
        }
        // keep same required fields as create (if business requires)
        if (rfq.getCreatedBy() == null || rfq.getCreatedBy() <= 0) {
            throw new ValidationException("rfq.createdBy must be a positive number");
        }
        if (rfq.getStatusAward() == null || rfq.getStatusAward().trim().isEmpty()) {
            throw new ValidationException("rfq.statusAward is required");
        }
    }

    private void validateItemDtos(List<RfqItemDto> items, boolean requireNonEmpty) {
        if (items == null) throw new ValidationException("items is required");
        if (requireNonEmpty && items.isEmpty()) throw new ValidationException("items cannot be empty");

        for (int i = 0; i < items.size(); i++) {
            RfqItemDto it = items.get(i);
            if (it == null) throw new ValidationException("items[" + i + "] must not be null");

            if (it.getQuantityNeeded() == null) {
                throw new ValidationException("items[" + i + "].quantityNeeded is required");
            }
            if (it.getQuantityNeeded() <= 0) {
                throw new ValidationException("items[" + i + "].quantityNeeded must be a positive number");
            }
        }
    }

    // ============================================================
    // Mapping helpers (DTO <-> Entity)
    // ============================================================

    private RfqDto toRfqDto(Rfq rfq) {
        RfqDto dto = new RfqDto();
        dto.setRfqId(rfq.getRfqId());
        dto.setCreatedBy(rfq.getCreatedBy());
        dto.setStatusAward(rfq.getStatusAward());
        dto.setSubmissionDeadline(rfq.getSubmissionDeadline());
        dto.setExpectedDeliveryDate(rfq.getExpectedDeliveryDate());
        return dto;
    }

    private RfqItemDto toItemDto(RfqItems item) {
        RfqItemDto dto = new RfqItemDto();
        dto.setRfqItemId(item.getRfqItemId());
        dto.setQuantityNeeded(item.getQuantityNeeded());
        return dto;
    }

    private Rfq toRfqEntity(RfqDto dto) {
        Rfq rfq = new Rfq();
        if (dto.getRfqId() != null) rfq.setRfqId(dto.getRfqId());
        if (dto.getCreatedBy() != null) rfq.setCreatedBy(dto.getCreatedBy());
        rfq.setStatusAward(dto.getStatusAward());
        rfq.setSubmissionDeadline(dto.getSubmissionDeadline());
        rfq.setExpectedDeliveryDate(dto.getExpectedDeliveryDate());
        return rfq;
    }

    private List<RfqItems> toItemEntities(List<RfqItemDto> dtos, Integer rfqId) {
        return dtos.stream().map(d -> {
            RfqItems it = new RfqItems();
            if (d.getRfqItemId() != null) it.setRfqItemId(d.getRfqItemId());
            if (rfqId != null) it.setRfqId(rfqId);
            if (d.getQuantityNeeded() != null) it.setQuantityNeeded(d.getQuantityNeeded());
            return it;
        }).collect(Collectors.toList());
    }
}