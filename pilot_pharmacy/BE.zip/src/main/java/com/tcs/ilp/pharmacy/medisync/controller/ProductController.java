package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.ProductCreateRequest;
import com.tcs.ilp.pharmacy.medisync.dto.ProductResponse;
import com.tcs.ilp.pharmacy.medisync.dto.ProductUpdateRequest;
import com.tcs.ilp.pharmacy.medisync.entity.Batch;
import com.tcs.ilp.pharmacy.medisync.entity.Product;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.ProductService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
@CrossOrigin()
@RestController
@RequestMapping("/api/v1/products")



public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    // ---------------- CREATE ----------------
    @PostMapping
    public ResponseEntity<ProductResponse> create(@RequestBody ProductCreateRequest request) {
        requireBody(request, "Request body is required");

        validateProductFields(
                request.getProductName(),
                request.getCategory(),
                request.getQuantityTotal(),
                request.getPrice(),
                request.getExpiryDate(),
                request.getBatchId()
        );

        Product product = toEntityForCreate(request);
        Product created = service.create(product);

        if (created == null || created.getProductId() == null) {
            // If service doesn't return id, it's an internal issue
            throw new RuntimeException("Product creation failed");
        }

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getProductId())
                .toUri();

        return ResponseEntity.status(HttpStatus.CREATED)
                .location(location)
                .body(toResponse(created));
    }

    // ---------------- READ ALL ----------------
    @GetMapping
    public ResponseEntity<List<ProductResponse>> getAll() {
        List<ProductResponse> out = service.getAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // ---------------- READ ONE ----------------
    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> getOne(@PathVariable int id) {
        requirePositive(id, "id");

        Product p = service.getById(id);
        if (p == null) throw new NotFoundException("Product not found");

        return ResponseEntity.ok(toResponse(p));
    }

    // ---------------- UPDATE ----------------
    @PutMapping("/{id}")
    public ResponseEntity<ProductResponse> update(@PathVariable int id,
                                                  @RequestBody ProductUpdateRequest request) {
        requirePositive(id, "id");
        requireBody(request, "Request body is required");

        validateProductFields(
                request.getProductName(),
                request.getCategory(),
                request.getQuantityTotal(),
                request.getPrice(),
                request.getExpiryDate(),
                request.getBatchId()
        );

        Product product = toEntityForUpdate(id, request);
        Product updated = service.update(id, product);

        if (updated == null) throw new NotFoundException("Product not found");

        return ResponseEntity.ok(toResponse(updated));
    }

    // ---------------- DELETE ----------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        requirePositive(id, "id");

        // If service throws NotFoundException itself, fine.
        // If not, you may want service.delete to return boolean.
        service.delete(id);

        return ResponseEntity.noContent().build();
    }

    // ---------------- MAPPERS ----------------

    private Product toEntityForCreate(ProductCreateRequest r) {
        Product p = new Product();
        p.setProductName(r.getProductName().trim());
        p.setCategory(r.getCategory().trim());
        p.setQuantityTotal(r.getQuantityTotal());
        p.setPrice(r.getPrice());
        p.setExpiryDate(r.getExpiryDate());

        Batch b = new Batch();
        b.setBatchId(r.getBatchId());
        p.setBatch(b);

        return p;
    }

    private Product toEntityForUpdate(int id, ProductUpdateRequest r) {
        Product p = new Product();
        p.setProductId(id);
        p.setProductName(r.getProductName().trim());
        p.setCategory(r.getCategory().trim());
        p.setQuantityTotal(r.getQuantityTotal());
        p.setPrice(r.getPrice());
        p.setExpiryDate(r.getExpiryDate());

        Batch b = new Batch();
        b.setBatchId(r.getBatchId());
        p.setBatch(b);

        return p;
    }

    private ProductResponse toResponse(Product p) {
        Integer batchId = (p.getBatch() != null) ? p.getBatch().getBatchId() : null;

        return new ProductResponse(
                p.getProductId(),
                p.getProductName(),
                p.getCategory(),
                p.getQuantityTotal(),
                p.getPrice(),
                p.getExpiryDate(),
                batchId
        );
    }

    // ---------------- VALIDATION HELPERS ----------------

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requirePositive(Integer value, String fieldName) {
        if (value == null || value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requireNotBlank(String value, String message) {
        if (value == null || value.isBlank()) throw new ValidationException(message);
    }

    private void validateProductFields(String productName,
                                       String category,
                                       Integer quantityTotal,
                                       Double price,
                                       LocalDate expiryDate,
                                       Integer batchId) {

        requireNotBlank(productName, "productName is required");
        requireNotBlank(category, "category is required");

        if (quantityTotal == null) throw new ValidationException("quantityTotal is required");
        if (quantityTotal < 0) throw new ValidationException("quantityTotal must be >= 0");

        if (price == null) throw new ValidationException("price is required");
        if (price <= 0) throw new ValidationException("price must be greater than 0");

        if (expiryDate == null) throw new ValidationException("expiryDate is required");
        if (expiryDate.isBefore(LocalDate.now())) {
            throw new ValidationException("expiryDate must not be in the past");
        }

        requirePositive(batchId, "batchId");
    }
}