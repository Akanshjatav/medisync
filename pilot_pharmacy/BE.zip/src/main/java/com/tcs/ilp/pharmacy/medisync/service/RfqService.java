package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.RfqItems;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.RfqRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RfqService {

    private final RfqRepository repo;

    public RfqService(RfqRepository repo) {
        this.repo = repo;
    }

    // ---------- READ ----------

    @Transactional(readOnly = true)
    public List<Rfq> listAll() {
        return repo.findAll();
    }

    @Transactional(readOnly = true)
    public Rfq getRfq(int rfqId) {
        return repo.findById(rfqId)
                .orElseThrow(() -> new NotFoundException("RFQ not found: " + rfqId));
    }

    @Transactional(readOnly = true)
    public List<RfqItems> getItems(int rfqId) {
        return getRfq(rfqId).getItems();
    }

    // ---------- WRITE ----------

    public Rfq create(Rfq rfq) {
        return repo.save(rfq);
    }

    public Rfq update(Rfq rfq) {
        if (rfq.getRfqId() == null) {
            throw new IllegalArgumentException("rfqId required for update");
        }

        Rfq existing = getRfq(rfq.getRfqId());

        existing.setStatusAward(rfq.getStatusAward());
        existing.setSubmissionDeadline(rfq.getSubmissionDeadline());
        existing.setExpectedDeliveryDate(rfq.getExpectedDeliveryDate());
        existing.setSpecialInstructions(rfq.getSpecialInstructions());

        // items are managed by cascade = ALL
        existing.getItems().clear();
        if (rfq.getItems() != null) {
            existing.getItems().addAll(rfq.getItems());
        }

        return repo.save(existing);
    }

    public void delete(int rfqId) {
        Rfq rfq = getRfq(rfqId);
        repo.delete(rfq);
    }

    // ---------- DOMAIN ----------

    public void award(int rfqId, String status) {
        Rfq rfq = getRfq(rfqId);
        rfq.setStatusAward(status);
        repo.save(rfq);
    }
}
