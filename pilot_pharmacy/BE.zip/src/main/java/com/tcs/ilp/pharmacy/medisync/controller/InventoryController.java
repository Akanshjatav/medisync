package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.InventoryCreateRequest;
import com.tcs.ilp.pharmacy.medisync.dto.InventoryPatchRequest;
import com.tcs.ilp.pharmacy.medisync.dto.InventoryPutRequest;
import com.tcs.ilp.pharmacy.medisync.dto.InventoryResponse;
import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.InventoryService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/inventories")
public class InventoryController {

    private final InventoryService service;

    public InventoryController(InventoryService service) {
        this.service = service;
    }

    @GetMapping("/health")
    public ResponseEntity<LinkedHashMap<String, Object>> health() {
        LinkedHashMap<String, Object> body = new LinkedHashMap<>();
        body.put("status", "UP");
        body.put("timestamp", LocalDateTime.now().toString());
        return ResponseEntity.ok(body);
    }

    // POST /api/v1/inventories
    @PostMapping
    public ResponseEntity<InventoryResponse> create(@Valid @RequestBody InventoryCreateRequest request) {
        // @Valid covers nulls, we validate positivity here
        requirePositive(request.getBatchId(), "batchId");
        requirePositive(request.getStoreId(), "storeId");

        Inventory created = service.createInventory(request.getBatchId(), request.getStoreId());
        return ResponseEntity.status(HttpStatus.CREATED).body(toResponse(created));
    }

    // GET /api/v1/inventories?storeId=&batchId=
    @GetMapping
    public ResponseEntity<List<InventoryResponse>> list(
            @RequestParam(required = false) Integer storeId,
            @RequestParam(required = false) Integer batchId
    ) {
        if (storeId != null) requirePositive(storeId, "storeId");
        if (batchId != null) requirePositive(batchId, "batchId");

        List<Inventory> list = service.getAllInventories(Optional.ofNullable(storeId), Optional.ofNullable(batchId));
        List<InventoryResponse> out = list.stream().map(this::toResponse).collect(Collectors.toList());
        return ResponseEntity.ok(out);
    }

    // GET /api/v1/inventories/{inventoryId}
    @GetMapping("/{inventoryId}")
    public ResponseEntity<InventoryResponse> getById(@PathVariable Integer inventoryId) {
        requirePositive(inventoryId, "inventoryId");

        Inventory inv = service.getInventoryById(inventoryId);
        if (inv == null) throw new NotFoundException("Inventory not found");

        return ResponseEntity.ok(toResponse(inv));
    }

    // PUT /api/v1/inventories/{inventoryId}
    @PutMapping("/{inventoryId}")
    public ResponseEntity<InventoryResponse> put(
            @PathVariable Integer inventoryId,
            @Valid @RequestBody InventoryPutRequest request
    ) {
        requirePositive(inventoryId, "inventoryId");
        requirePositive(request.getBatchId(), "batchId");
        requirePositive(request.getStoreId(), "storeId");

        Inventory updated = service.replaceInventory(inventoryId, request.getBatchId(), request.getStoreId());
        if (updated == null) throw new NotFoundException("Inventory not found");

        return ResponseEntity.ok(toResponse(updated));
    }

    // PATCH /api/v1/inventories/{inventoryId}
    @PatchMapping("/{inventoryId}")
    public ResponseEntity<InventoryResponse> patch(
            @PathVariable Integer inventoryId,
            @RequestBody InventoryPatchRequest request
    ) {
        requirePositive(inventoryId, "inventoryId");

        if (request == null || (request.getBatchId() == null && request.getStoreId() == null)) {
            throw new ValidationException("Provide at least one field to update (batchId/storeId).");
        }

        if (request.getBatchId() != null) requirePositive(request.getBatchId(), "batchId");
        if (request.getStoreId() != null) requirePositive(request.getStoreId(), "storeId");

        Inventory updated = service.patchInventory(inventoryId, request.getBatchId(), request.getStoreId());
        if (updated == null) throw new NotFoundException("Inventory not found");

        return ResponseEntity.ok(toResponse(updated));
    }

    // DELETE /api/v1/inventories/{inventoryId}
    @DeleteMapping("/{inventoryId}")
    public ResponseEntity<Void> delete(@PathVariable Integer inventoryId) {
        requirePositive(inventoryId, "inventoryId");
        service.deleteInventory(inventoryId);
        return ResponseEntity.noContent().build();
    }

    // ---------------- helpers ----------------

    private InventoryResponse toResponse(Inventory inv) {
        // Assumes these getters exist on entity
        return new InventoryResponse(
                inv.getInventoryId(),
                inv.getBatches(),
                inv.getStore()
        );
    }

    private void requirePositive(Integer value, String fieldName) {
        if (value == null || value <= 0) {
            throw new ValidationException(fieldName + " must be a positive number");
        }
    }
}