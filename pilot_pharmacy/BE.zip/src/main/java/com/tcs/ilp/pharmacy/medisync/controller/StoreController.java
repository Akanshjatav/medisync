package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.StoreService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/branches") // keep backward compatible
@CrossOrigin
public class StoreController {

    private final StoreService service;

    public StoreController(StoreService service) {
        this.service = service;
    }

    // ---------- CREATE ----------
    @PostMapping
    public ResponseEntity<Stores> create(@RequestBody Stores store) {
        requireBody(store, "Request body is required");

        Stores created = service.createStore(store);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getStoreId())
                .toUri();

        return ResponseEntity.status(HttpStatus.CREATED)
                .location(location)
                .body(created);
    }

    // ---------- READ ONE ----------
    @GetMapping("/{id}")
    public ResponseEntity<Stores> getOne(@PathVariable int id) {
        requirePositive(id, "id");
        return ResponseEntity.ok(service.getStoreById(id)); // should throw StoreNotFoundException if missing
    }

    // ---------- READ ALL / SEARCH ----------
    @GetMapping
    public ResponseEntity<List<Stores>> getAll(@RequestParam(required = false) String q) {

        if (q != null) {
            q = q.trim();
            if (q.isEmpty()) q = null;
            if (q != null && q.length() > 100) {
                throw new ValidationException("q must not exceed 100 characters");
            }
        }

        List<Stores> data = (q != null)
                ? service.searchByLocation(q)
                : service.getAllStores();

        return ResponseEntity.ok(data);
    }

    // ---------- UPDATE ----------
    @PutMapping("/{id}")
    public ResponseEntity<Stores> update(@PathVariable int id, @RequestBody Stores store) {
        requirePositive(id, "id");
        requireBody(store, "Request body is required");

        store.setStoreId(id); // enforce path id as source of truth
        return ResponseEntity.ok(service.updateStore(id, store)); // should throw StoreNotFoundException if missing
    }

    // ---------- DELETE ----------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        requirePositive(id, "id");
        service.deleteStore(id); // should throw StoreNotFoundException if missing
        return ResponseEntity.noContent().build(); // 204
    }

    // ---------- EXISTS ----------
    @GetMapping("/{id}/exists")
    public ResponseEntity<Boolean> exists(@PathVariable int id) {
        requirePositive(id, "id");
        return ResponseEntity.ok(service.exists(id));
    }

    // ---------------- validation helpers ----------------

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }
}