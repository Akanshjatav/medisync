package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.BatchCreateRequest;
import com.tcs.ilp.pharmacy.medisync.dto.BatchResponse;
import com.tcs.ilp.pharmacy.medisync.dto.BatchUpdateRequest;
import com.tcs.ilp.pharmacy.medisync.entity.Batch;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.BatchService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/batches")
public class BatchController {

    private final BatchService batchService;

    public BatchController(BatchService batchService) {
        this.batchService = batchService;
    }

    // -------------------- CREATE --------------------
    // POST /api/v1/batches
    @PostMapping
    public ResponseEntity<BatchResponse> createBatch(@RequestBody BatchCreateRequest request) {
        requireBody(request, "Request body is required");

        validateBatchNumber(request.getBatchNumber());
        requireNotNull(request.getDeliveryDate(), "deliveryDate is required");
        requirePositive(request.getVendorId(), "vendorId");

        Batch batch = new Batch();
        batch.setBatchNumber(request.getBatchNumber());
        batch.setDeliveryDate(request.getDeliveryDate());
        batch.setVendorId(request.getVendorId());

        Batch created = batchService.addBatch(batch);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getBatchId())
                .toUri();

        return ResponseEntity.status(HttpStatus.CREATED)
                .location(location)
                .body(toResponse(created));
    }

    // -------------------- READ --------------------
    // GET /api/v1/batches/{id}
    @GetMapping("/{id}")
    public ResponseEntity<BatchResponse> getBatchById(@PathVariable int id) {
        requirePositive(id, "id");

        Batch batch = batchService.getBatch(id)
                .orElseThrow(() -> new NotFoundException("Batch not found"));

        return ResponseEntity.ok(toResponse(batch));
    }

    // GET /api/v1/batches
    @GetMapping
    public ResponseEntity<List<BatchResponse>> listAllBatches() {
        List<BatchResponse> out = batchService.listAllBatches().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // GET /api/v1/batches/vendor/{vendorId}
    @GetMapping("/vendor/{vendorId}")
    public ResponseEntity<List<BatchResponse>> getBatchesByVendor(@PathVariable int vendorId) {
        requirePositive(vendorId, "vendorId");

        List<BatchResponse> out = batchService.getByVendor(vendorId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // GET /api/v1/batches/delivered?from=2026-01-01&to=2026-01-31
    @GetMapping("/delivered")
    public ResponseEntity<List<BatchResponse>> getDeliveredBetween(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        // If from/to missing, Spring throws MissingServletRequestParameterException -> handled by GlobalExceptionHandler
        if (from.isAfter(to)) {
            throw new ValidationException("from must be before or equal to to");
        }

        List<BatchResponse> out = batchService.getDeliveredBetween(from, to).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // GET /api/v1/batches/page?page=1&size=10
    @GetMapping("/page")
    public ResponseEntity<List<BatchResponse>> getPage(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        if (page < 1) throw new ValidationException("page must be >= 1");
        if (size < 1 || size > 100) throw new ValidationException("size must be between 1 and 100");

        List<BatchResponse> out = batchService.getPage(page, size).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // GET /api/v1/batches/sorted?asc=true
    @GetMapping("/sorted")
    public ResponseEntity<List<BatchResponse>> getSortedByDeliveryDate(
            @RequestParam(defaultValue = "true") boolean asc
    ) {
        List<BatchResponse> out = batchService.getSortedByDeliveryDate(asc).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return ResponseEntity.ok(out);
    }

    // -------------------- UPDATE --------------------
    // PUT /api/v1/batches/{id}
    @PutMapping("/{id}")
    public ResponseEntity<BatchResponse> updateBatch(@PathVariable int id,
                                                     @RequestBody BatchUpdateRequest request) {
        requirePositive(id, "id");
        requireBody(request, "Request body is required");

        validateBatchNumber(request.getBatchNumber());
        requireNotNull(request.getDeliveryDate(), "deliveryDate is required");
        requirePositive(request.getVendorId(), "vendorId");

        Batch batch = new Batch();
        batch.setBatchId(id); // path id wins
        batch.setBatchNumber(request.getBatchNumber());
        batch.setDeliveryDate(request.getDeliveryDate());
        batch.setVendorId(request.getVendorId());

        Batch updated = batchService.updateBatch(batch);

        if (updated == null) {
            throw new NotFoundException("Batch not found");
        }

        return ResponseEntity.ok(toResponse(updated));
    }

    // -------------------- DELETE --------------------
    // DELETE /api/v1/batches/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBatch(@PathVariable int id) {
        requirePositive(id, "id");

        boolean deleted = batchService.removeBatch(id);
        if (!deleted) {
            throw new NotFoundException("Batch not found");
        }

        return ResponseEntity.noContent().build();
    }

    // -------------------- Helpers --------------------

    private BatchResponse toResponse(Batch b) {
        return new BatchResponse(
                b.getBatchId(),
                b.getBatchNumber(),
                b.getDeliveryDate(),
                b.getVendorId()
        );
    }

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requireNotNull(Object value, String message) {
        if (value == null) throw new ValidationException(message);
    }

    private void requirePositive(Integer value, String fieldName) {
        if (value == null || value <= 0) {
            throw new ValidationException(fieldName + " must be a positive number");
        }
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) {
            throw new ValidationException(fieldName + " must be a positive number");
        }
    }

    private void validateBatchNumber(Integer batchNumber) {
        if (batchNumber == null) {
            throw new ValidationException("batchNumber is required");
        }
        if (batchNumber <= 0) {
            throw new ValidationException("batchNumber must be a positive number");
        }
    }
}