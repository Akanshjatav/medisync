package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.exception.StoreNotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.StoreRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StoreService {

    private final StoreRepository repo;

    public StoreService(StoreRepository repo) {
        this.repo = repo;
    }

    public Stores createStore(Stores store) {
        if (store.getLocation() == null || store.getLocation().isBlank()) {
            throw new IllegalArgumentException("location is required");
        }
        if (store.getManager() == null || store.getPharmacist() == null) {
            throw new IllegalArgumentException("manager and pharmacist required");
        }
        

        return repo.save(store);
    }

    @Transactional(readOnly = true)
    public Stores getStoreById(int id) {
        return repo.findById(id)
                .orElseThrow(() -> new StoreNotFoundException("Store not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Stores> getAllStores() {
        return repo.findAll();
    }

    public Stores updateStore(int id, Stores updated) {
        Stores existing = getStoreById(id);

        existing.setLocation(updated.getLocation());
        existing.setAddress(updated.getAddress());
        existing.setStoreName(updated.getStoreName());
        existing.setInventory(updated.getInventory());
        existing.setManager(updated.getManager());
        existing.setPharmacist(updated.getPharmacist());

        return repo.save(existing);
    }

    public void deleteStore(int id) {
        repo.delete(getStoreById(id));
    }
}
