package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.LoginRequest;
import com.tcs.ilp.pharmacy.medisync.dto.LoginResponse;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.repository.UsersRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AuthService {

    private final UsersRepository usersRepository;

    public AuthService(UsersRepository usersRepository) {
        this.usersRepository = usersRepository;
    }

    public LoginResponse login(LoginRequest request) {
        if (request == null) {
            throw new ValidationException("Request body is required");
        }

        if (request.getEmail() == null || request.getPassword() == null) {
            throw new ValidationException("email and password are required");
        }

        Users user = usersRepository.findByEmail(request.getEmail().trim())
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));

        if (!user.isActive() || !user.getPassword().equals(request.getPassword())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        }

        return new LoginResponse(
                user.getUserId(),
                user.getName(),
                user.getRole().getRoleId()
        );
    }
}
