package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.BidItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidRequestDto;
import com.tcs.ilp.pharmacy.medisync.entity.BidItems;
import com.tcs.ilp.pharmacy.medisync.entity.Bids;
import com.tcs.ilp.pharmacy.medisync.entity.Rfq;
import com.tcs.ilp.pharmacy.medisync.entity.Vendor;
import com.tcs.ilp.pharmacy.medisync.exception.ResourceNotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.BidsRepository;
import com.tcs.ilp.pharmacy.medisync.repository.RfqRepository;
import com.tcs.ilp.pharmacy.medisync.repository.VendorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class BidsService {

    private final BidsRepository bidsRepo;
    private final VendorRepository vendorRepo;
    private final RfqRepository rfqRepo;

    public BidsService(BidsRepository bidsRepo,
                       VendorRepository vendorRepo,
                       RfqRepository rfqRepo) {
        this.bidsRepo = bidsRepo;
        this.vendorRepo = vendorRepo;
        this.rfqRepo = rfqRepo;
    }

    public Bids createBid(BidRequestDto dto) {
        Vendor vendor = vendorRepo.findById(dto.getVendorId())
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found"));

        Rfq rfq = rfqRepo.findById(dto.getRfqId())
                .orElseThrow(() -> new ResourceNotFoundException("RFQ not found"));

        Bids bid = new Bids();
        bid.setVendor(vendor);
        bid.setRfq(rfq);

        if (dto.getItems() != null) {
            bid.setItems(mapItems(dto.getItems(), bid));
        }

        return bidsRepo.save(bid);
    }

    @Transactional(readOnly = true)
    public Bids getBid(int bidId) {
        return bidsRepo.findById(bidId)
                .orElseThrow(() -> new ResourceNotFoundException("Bid not found: " + bidId));
    }

    @Transactional(readOnly = true)
    public List<Bids> getAll() {
        return bidsRepo.findAll();
    }

    public void delete(int bidId) {
        bidsRepo.delete(getBid(bidId));
    }

    // ---------- helpers ----------

    private List<BidItems> mapItems(List<BidItemDto> dtoItems, Bids bid) {
        List<BidItems> items = new ArrayList<>();
        for (BidItemDto dto : dtoItems) {
            BidItems it = new BidItems();
            it.setMedicineName(dto.getMedicineName());
            it.setItemPrice(dto.getItemPrice());
            it.setItemQuantity(dto.getItemQuantity());
            it.setBids(bid);
            items.add(it);
        }
        return items;
    }
}
