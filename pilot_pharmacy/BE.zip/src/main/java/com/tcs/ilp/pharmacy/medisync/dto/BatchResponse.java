package com.tcs.ilp.pharmacy.medisync.dto;

import java.time.LocalDate;

public class BatchResponse {
    private Integer batchId;
    private Integer batchNumber;
    private LocalDate deliveryDate;
    private Integer vendorId;

    public BatchResponse() {}

    public BatchResponse(Integer batchId, Integer batchNumber, LocalDate deliveryDate, Integer vendorId) {
        this.batchId = batchId;
        this.batchNumber = batchNumber;
        this.deliveryDate = deliveryDate;
        this.vendorId = vendorId;
    }

    public Integer getBatchId() { return batchId; }
    public void setBatchId(Integer batchId) { this.batchId = batchId; }

    public Integer getBatchNumber() { return batchNumber; }
    public void setBatchNumber(Integer batchNumber) { this.batchNumber = batchNumber; }

    public LocalDate getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDate deliveryDate) { this.deliveryDate = deliveryDate; }

    public Integer getVendorId() { return vendorId; }
    public void setVendorId(Integer vendorId) { this.vendorId = vendorId; }
}