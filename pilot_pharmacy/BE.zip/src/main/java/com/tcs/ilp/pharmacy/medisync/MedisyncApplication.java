package com.tcs.ilp.pharmacy.medisync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//final integration file
@SpringBootApplication
public class MedisyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedisyncApplication.class, args);
	}

}
