package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.BidItemDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidItemsUpdateDto;
import com.tcs.ilp.pharmacy.medisync.dto.BidRequestDto;
import com.tcs.ilp.pharmacy.medisync.entity.BidItems;
import com.tcs.ilp.pharmacy.medisync.entity.Bids;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.BidsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Collectors;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/bids")
public class BidsController {

    private final BidsService service;

    public BidsController(BidsService service) {
        this.service = service;
    }

    // ============================================================
    // GET
    // ============================================================

    /**
     * GET /api/v1/bids?vendorId=3&rfqId=9
     * Both filters optional.
     */
 
    /**
     * GET /api/v1/bids/{bidId}
     */
    @GetMapping("/{bidId}")
    public ResponseEntity<Bids> getBidById(@PathVariable int bidId) {
        requirePositive(bidId, "bidId");
        return ResponseEntity.ok(service.getBidById(bidId));
    }

    /**
     * GET /api/v1/bids/{bidId}/items
     */
    @GetMapping("/{bidId}/items")
    public ResponseEntity<List<BidItems>> getBidItems(@PathVariable int bidId) {
        requirePositive(bidId, "bidId");
        return ResponseEntity.ok(service.getBidItemsByBidId(bidId));
    }

// ...

    /**
     * GET /api/v1/bids
     * Optional filters:
     * - /api/v1/bids?vendorId=3
     * - /api/v1/bids?rfqId=9
     * - /api/v1/bids?vendorId=3&rfqId=9
     */
    @GetMapping
    public ResponseEntity<List<Bids>> getAllBids(
            @RequestParam(required = false) Integer vendorId,
            @RequestParam(required = false) Integer rfqId) {

        // validate optional params
        if (vendorId != null) requirePositive(vendorId, "vendorId");
        if (rfqId != null) requirePositive(rfqId, "rfqId");

        List<Bids> data;

        // no filters -> all bids
        if (vendorId == null && rfqId == null) {
            data = service.getAllBids();
        }
        // only vendorId
        else if (vendorId != null && rfqId == null) {
            data = service.getBidsByVendor(vendorId);
        }
        // only rfqId
        else if (vendorId == null) { // rfqId != null
            data = service.getBidsByRfq(rfqId);
        }
        // both vendorId and rfqId -> filter using existing service method
        else {
            data = service.getBidsByVendor(vendorId).stream()
                    .filter(b -> b.getRfq() != null
                            && b.getRfq().getRfqId() != null
                            && b.getRfq().getRfqId().equals(rfqId))
                    .collect(Collectors.toList());
        }

        return ResponseEntity.ok(data);
    }

    // ============================================================
    // POST
    // ============================================================

    /**
     * POST /api/v1/bids
     * Body:
     * {
     *   "vendorId": 3,
     *   "rfqId": 9,
     *   "items": [ { "itemPrice": 12.5, "itemQuantity": 100 } ]
     * }
     */
    @PostMapping
    public ResponseEntity<Bids> createBid(@RequestBody BidRequestDto dto) {

        requireBody(dto, "Request body is required");
        requirePositive(dto.getVendorId(), "vendorId");
        requirePositive(dto.getRfqId(), "rfqId");

        // items required and must be non-empty for creation
        requireNonEmptyList(dto.getItems(), "items cannot be empty");

        validateBidItemDtos(dto.getItems());

        Bids saved = service.createBid(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // ============================================================
    // PUT (header only)
    // ============================================================

    /**
     * PUT /api/v1/bids/{bidId}
     * Header-only update; items are ignored.
     * Body:
     * { "vendorId": 4, "rfqId": 9 }
     */
    @PutMapping("/{bidId}")
    public ResponseEntity<Bids> updateBidHeader(@PathVariable int bidId,
                                                @RequestBody BidRequestDto dto) {

        requirePositive(bidId, "bidId");
        requireBody(dto, "Request body is required");

        requirePositive(dto.getVendorId(), "vendorId");
        requirePositive(dto.getRfqId(), "rfqId");

        // DO NOT validate items here (ignored)
        return ResponseEntity.ok(service.updateBidHeader(bidId, dto));
    }

    // ============================================================
    // PUT (replace items)
    // ============================================================

    /**
     * PUT /api/v1/bids/{bidId}/items
     * Replaces items completely.
     * Body must contain 'items' field (can be empty to clear).
     * { "items": [] } clears all
     */
    @PutMapping("/{bidId}/items")
    public ResponseEntity<Bids> replaceBidItems(@PathVariable int bidId,
                                                @RequestBody BidItemsUpdateDto dto) {

        requirePositive(bidId, "bidId");
        requireBody(dto, "Request body is required");

        // items must be present (can be empty)
        if (dto.getItems() == null) {
            throw new ValidationException("items field is required (can be empty to clear)");
        }

        validateBidItemDtos(dto.getItems());
        return ResponseEntity.ok(service.replaceBidItems(bidId, dto));
    }

    // ============================================================
    // PUT (update one item)
    // ============================================================

    /**
     * PUT /api/v1/bids/items/{bidItemId}
     * Body contains itemPrice/itemQuantity. Path ID is source of truth.
     */
    @PutMapping("/items/{bidItemId}")
    public ResponseEntity<Void> updateBidItem(@PathVariable int bidItemId,
                                              @RequestBody BidItems item) {

        requirePositive(bidItemId, "bidItemId");
        requireBody(item, "Request body is required");

        // validate editables
        requirePositive(item.getItemQuantity(), "itemQuantity");
        requireGreaterThanZero(item.getItemPrice(), "itemPrice");

        // enforce path id as source of truth
        item.setBidItemId(bidItemId);

        service.updateBidItem(bidItemId, item);
        return ResponseEntity.noContent().build();
    }

    // ============================================================
    // DELETE
    // ============================================================

    @DeleteMapping("/{bidId}")
    public ResponseEntity<Void> deleteBid(@PathVariable int bidId) {
        requirePositive(bidId, "bidId");
        service.deleteBid(bidId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/items/{bidItemId}")
    public ResponseEntity<Void> deleteBidItem(@PathVariable int bidItemId) {
        requirePositive(bidItemId, "bidItemId");
        service.deleteBidItem(bidItemId);
        return ResponseEntity.noContent().build();
    }

    // ============================================================
    // Validation helpers (manual, crisp)
    // ============================================================

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requireNonEmptyList(List<?> list, String message) {
        if (list == null || list.isEmpty()) throw new ValidationException(message);
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requirePositive(Integer value, String fieldName) {
        if (value == null || value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requireGreaterThanZero(BigDecimal value, String fieldName) {
        if (value == null) throw new ValidationException(fieldName + " is required");
        if (value.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException(fieldName + " must be greater than 0");
        }
    }

    private void validateBidItemDtos(List<BidItemDto> items) {
        if (items == null) return; // handled where required

        for (int i = 0; i < items.size(); i++) {
            BidItemDto di = items.get(i);
            if (di == null) {
                throw new ValidationException("items[" + i + "] must not be null");
            }
            if (di.getItemQuantity() <= 0) {
                throw new ValidationException("items[" + i + "].itemQuantity must be a positive number");
            }
            if (di.getItemPrice() == null) {
                throw new ValidationException("items[" + i + "].itemPrice is required");
            }
            if (di.getItemPrice().compareTo(BigDecimal.ZERO) <= 0) {
                throw new ValidationException("items[" + i + "].itemPrice must be greater than 0");
            }
        }
    }
}
