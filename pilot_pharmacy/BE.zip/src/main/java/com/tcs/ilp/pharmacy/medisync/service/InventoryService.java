package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.exception.ConflictException;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.repository.InventoryRepository;
import com.tcs.ilp.pharmacy.medisync.repository.StoreRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class InventoryService {

    private final InventoryRepository inventoryRepository;
    private final StoreRepository storeRepository;

    public InventoryService(InventoryRepository inventoryRepository,
                            StoreRepository storeRepository) {
        this.inventoryRepository = inventoryRepository;
        this.storeRepository = storeRepository;
    }

    public Inventory createInventory(Integer storeId) {
        Stores store = storeRepository.findById(storeId)
                .orElseThrow(() -> new NotFoundException("Store not found: " + storeId));

        if (inventoryRepository.existsByStore_StoreId(storeId)) {
            throw new ConflictException("Inventory already exists for store");
        }

        Inventory inventory = new Inventory();
        inventory.setStore(store);

        return inventoryRepository.save(inventory);
    }

    @Transactional(readOnly = true)
    public Inventory getInventory(int inventoryId) {
        return inventoryRepository.findById(inventoryId)
                .orElseThrow(() -> new NotFoundException("Inventory not found: " + inventoryId));
    }

    public void deleteInventory(int inventoryId) {
        inventoryRepository.delete(getInventory(inventoryId));
    }
}
