package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.VendorDocumentResponse;
import com.tcs.ilp.pharmacy.medisync.dto.VendorDocumentUploadRequest;
import com.tcs.ilp.pharmacy.medisync.dto.VendorRegisterRequest;
import com.tcs.ilp.pharmacy.medisync.dto.VendorResponse;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.VendorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/vendors")
public class VendorController {

    private final VendorService vendorService;

    public VendorController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    @GetMapping
    public ResponseEntity<List<VendorResponse>> getAllVendors() {
        return ResponseEntity.ok(vendorService.getAllVendors());
    }

    @PostMapping("/register")
    public ResponseEntity<VendorResponse> registerVendor(@Valid @RequestBody VendorRegisterRequest request) {
        // Optional: extra manual checks only if truly needed beyond annotations
        // Example: if you want to enforce password rules, you can do here.
        return ResponseEntity.status(HttpStatus.CREATED).body(vendorService.registerVendor(request));
    }

    @PostMapping("/{vendorId}/documents")
    public ResponseEntity<VendorDocumentResponse> uploadDocument(
            @PathVariable Integer vendorId,
            @Valid @RequestBody VendorDocumentUploadRequest request) {

        if (vendorId == null || vendorId <= 0) {
            throw new ValidationException("vendorId must be a positive number");
        }

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(vendorService.uploadDocument(vendorId, request));
    }
}