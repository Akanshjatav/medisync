package com.tcs.ilp.pharmacy.medisync.controller;

import com.tcs.ilp.pharmacy.medisync.dto.UserCreateRequest;
import com.tcs.ilp.pharmacy.medisync.dto.UserResponse;
import com.tcs.ilp.pharmacy.medisync.dto.UserUpdateRequest;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.exception.NotFoundException;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.UsersService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/users")
public class UsersController {

    private final UsersService userService;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public UsersController(UsersService userService) {
        this.userService = userService;
    }

    // ---------- CREATE ----------
    @PostMapping
    public ResponseEntity<UserResponse> create(@RequestBody UserCreateRequest request) {
        requireBody(request, "Request body is required");

        validateCreate(request);

        Users u = new Users();
        u.setRoleId(request.getRoleId());
        u.setActive(request.getIsActive() == null ? true : request.getIsActive());
        u.setName(request.getName().trim());
        u.setEmail(request.getEmail().trim());
        u.setPhoneNumber(cleanOptional(request.getPhoneNumber()));
        u.setPassword(request.getPassword()); // hashing should happen in service ideally

        int id = userService.addUser(u);

        URI location = URI.create("/api/v1/users/" + id);

        Users created = userService.getUser(id);
        if (created == null) throw new NotFoundException("User not found");

        return ResponseEntity.created(location).body(toResponse(created));
    }

    // ---------- READ ONE ----------
    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getOne(@PathVariable int id) {
        requirePositive(id, "id");

        Users u = userService.getUser(id);
        if (u == null) throw new NotFoundException("User not found");

        return ResponseEntity.ok(toResponse(u));
    }

    // ---------- READ ALL ----------
    @GetMapping
    public ResponseEntity<List<UserResponse>> getAll() {
        List<UserResponse> out = userService.getAllUsers().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(out);
    }

    // ---------- UPDATE (full replace with password optional) ----------
    @PutMapping("/{id}")
    public ResponseEntity<UserResponse> update(@PathVariable int id, @RequestBody UserUpdateRequest request) {
        requirePositive(id, "id");
        requireBody(request, "Request body is required");

        Users existing = userService.getUser(id);
        if (existing == null) throw new NotFoundException("User not found");

        validateUpdate(request);

        Users u = new Users();
        u.setUserId(id);

        u.setRoleId(request.getRoleId());
        if (request.getIsActive() == null) {
            u.setActive(existing.isActive());
        } else {
            u.setActive(request.getIsActive());
        }

        u.setName(request.getName().trim());
        u.setEmail(request.getEmail().trim());
        u.setPhoneNumber(cleanOptional(request.getPhoneNumber()));

        // password optional on update: keep existing if not provided
        if (request.getPassword() == null || request.getPassword().isBlank()) {
            u.setPassword(existing.getPassword());
        } else {
            u.setPassword(request.getPassword());
        }

        userService.updateUser(u);

        Users updated = userService.getUser(id);
        if (updated == null) throw new NotFoundException("User not found");

        return ResponseEntity.ok(toResponse(updated));
    }

    // ---------- DELETE ----------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        requirePositive(id, "id");
        userService.removeUser(id);
        return ResponseEntity.noContent().build();
    }


    // ---------------- MAPPER ----------------

    private UserResponse toResponse(Users u) {
        return new UserResponse(
                u.getUserId(),
                u.getRoleId(),
                u.isActive(),
                u.getName(),
                u.getEmail(),
                u.getPhoneNumber(),
                u.getCreatedAt(),
                u.getUpdatedAt()
        );
    }

    // ---------------- VALIDATION ----------------

    private void validateCreate(UserCreateRequest r) {
        requirePositive(r.getRoleId(), "roleId");
        requireNotBlank(r.getName(), "name is required");
        requireNotBlank(r.getEmail(), "email is required");
        requireEmail(r.getEmail());
        requireNotBlank(r.getPassword(), "password is required");

        if (r.getPhoneNumber() != null && r.getPhoneNumber().length() > 15) {
            throw new ValidationException("phoneNumber must not exceed 15 characters");
        }
    }

    private void validateUpdate(UserUpdateRequest r) {
        requirePositive(r.getRoleId(), "roleId");
        requireNotBlank(r.getName(), "name is required");
        requireNotBlank(r.getEmail(), "email is required");
        requireEmail(r.getEmail());

        if (r.getPhoneNumber() != null && r.getPhoneNumber().length() > 15) {
            throw new ValidationException("phoneNumber must not exceed 15 characters");
        }
        // password is optional in update
    }

    private void requireBody(Object body, String message) {
        if (body == null) throw new ValidationException(message);
    }

    private void requirePositive(Integer value, String fieldName) {
        if (value == null || value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }

    private void requireNotBlank(String value, String message) {
        if (value == null || value.isBlank()) throw new ValidationException(message);
    }

    private void requireEmail(String email) {
        if (email == null || email.isBlank()) return;
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new ValidationException("email is invalid");
        }
    }

    private String cleanOptional(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }
}