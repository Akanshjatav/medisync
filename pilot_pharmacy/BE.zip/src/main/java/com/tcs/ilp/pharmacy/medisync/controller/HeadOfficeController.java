package com.tcs.ilp.pharmacy.medisync.controller;


import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import com.tcs.ilp.pharmacy.medisync.entity.Stores;
import com.tcs.ilp.pharmacy.medisync.exception.ValidationException;
import com.tcs.ilp.pharmacy.medisync.service.InventoryService;
import com.tcs.ilp.pharmacy.medisync.service.ProductService;
import com.tcs.ilp.pharmacy.medisync.service.StoreService;
import com.tcs.ilp.pharmacy.medisync.service.UsersService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("api/v1/ho")
public class HeadOfficeController {

    private final StoreService storeService;
    private final InventoryService inventoryService;
    private  final ProductService productService;
    private final UsersService usersService;


    public HeadOfficeController(StoreService storeService,InventoryService inventoryService, ProductService productService, UsersService usersService){
        this.inventoryService = inventoryService;
        this.storeService = storeService;
        this.productService = productService;
        this.usersService = usersService;
    }

    @PostMapping("/register-branch")
    public ResponseEntity<Stores> create(@RequestBody Stores store) {
        if(store==null) throw  new ValidationException("Request Body is Required");
       Stores created = storeService.createStore(store);
        Inventory inventory = inventoryService.createInventory(created.getStoreId());
        created.setInventory(inventory);
        storeService.updateStore(created.getStoreId(), created);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(created);
    }










    private void requirePositive(int value, String fieldName) {
        if (value <= 0) throw new ValidationException(fieldName + " must be a positive number");
    }
}
