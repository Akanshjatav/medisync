package com.tcs.ilp.pharmacy.medisync.dto;

public class StoreCreateRequest {
}
