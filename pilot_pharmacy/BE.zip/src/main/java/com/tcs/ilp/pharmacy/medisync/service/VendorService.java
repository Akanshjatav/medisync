package com.tcs.ilp.pharmacy.medisync.service;

import com.tcs.ilp.pharmacy.medisync.dto.VendorRegisterRequest;
import com.tcs.ilp.pharmacy.medisync.dto.VendorResponse;
import com.tcs.ilp.pharmacy.medisync.entity.Users;
import com.tcs.ilp.pharmacy.medisync.entity.Vendor;
import com.tcs.ilp.pharmacy.medisync.repository.UsersRepository;
import com.tcs.ilp.pharmacy.medisync.repository.VendorRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@Transactional
public class VendorService {

    private final VendorRepository vendorRepository;
    private final UsersRepository usersRepository;

    public VendorService(VendorRepository vendorRepository,
                         UsersRepository usersRepository) {
        this.vendorRepository = vendorRepository;
        this.usersRepository = usersRepository;
    }

    public VendorResponse registerVendor(VendorRegisterRequest request) {

        if (vendorRepository.existsByGstNumber(request.getGstNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "GST Number already exists");
        }
        if (vendorRepository.existsByLicenseNumber(request.getLicenseNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "License Number already exists");
        }

        Users user = new Users();
        user.setName(request.getBusinessName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setActive(true);

        usersRepository.save(user);

        Vendor vendor = new Vendor();
        vendor.setUser(user);
        vendor.setGstNumber(request.getGstNumber());
        vendor.setLicenseNumber(request.getLicenseNumber());
        vendor.setAddress(request.getAddress());
        vendor.setStatus("PENDING");

        Vendor saved = vendorRepository.save(vendor);
        return toVendorResponse(saved);
    }

    private VendorResponse toVendorResponse(Vendor vendor) {
        VendorResponse res = new VendorResponse();
        res.setVendorId(vendor.getVendorId());
        res.setUserId(vendor.getUser().getUserId());
        res.setBusinessName(vendor.getUser().getName());
        res.setEmail(vendor.getUser().getEmail());
        res.setPhoneNumber(vendor.getUser().getPhoneNumber());
        res.setGstNumber(vendor.getGstNumber());
        res.setLicenseNumber(vendor.getLicenseNumber());
        res.setAddress(vendor.getAddress());
        res.setStatus(vendor.getStatus());
        res.setCreatedAt(vendor.getCreatedAt());
        res.setUpdatedAt(vendor.getUpdatedAt());
        return res;
    }
}
