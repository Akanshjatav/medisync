
package com.tcs.ilp.pharmacy.medisync.repository;

import com.tcs.ilp.pharmacy.medisync.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

    boolean existsByBatch_BatchIdAndStore_StoreId(Integer batchId, Integer storeId);

    Optional<Inventory> findByBatch_BatchIdAndStore_StoreId(Integer batchId, Integer storeId);

    List<Inventory> findByStore_StoreId(Integer storeId);
    boolean existsByStore_StoreId(Integer storeId);

    List<Inventory> findByBatch_BatchId(Integer batchId);
}
