package com.tcs.ilp.pharmacy.medisync.controller;

public class PharmacistController {
}
